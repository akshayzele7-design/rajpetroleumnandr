import React from 'react';
import { Phone, Navigation, MapPin, ShieldCheck, Clock } from 'lucide-react';
import { BusinessSettings, HomepageAppearance } from '../types';

interface HeroProps {
  settings: BusinessSettings | null;
  appearance?: HomepageAppearance | null;
}

export const Hero: React.FC<HeroProps> = ({ settings, appearance }) => {
  const phone = settings?.phone || '93721 47039';
  const whatsapp = settings?.whatsapp || '8766660414';
  const directionsUrl =
    'https://www.google.com/maps/dir/?api=1&destination=Raj+Petroleum%2C+WGXW%2BGXR%2C+Nandre%2C+Miraj%2C+Sangli%2C+Maharashtra+416416';
  const cleanPhone = phone.replace(/\D/g, '');
  const cleanWhatsapp = whatsapp.replace(/\D/g, '');
  const callHref = `tel:${cleanPhone}`;
  const whatsappHref = `https://wa.me/91${cleanWhatsapp.slice(-10)}`;

  // Appearance customization with graceful fallbacks
  const bgImage = appearance?.background_image?.trim() || '/assets/raj-petroleum-hero.jpg';
  const position = appearance?.position || 'center';
  const displayMode = appearance?.display_mode || 'cover';
  const overlayAlpha = appearance?.overlay_intensity !== undefined ? appearance.overlay_intensity : 0.45;
  const desktopHeight = appearance?.hero_height ? `${appearance.hero_height}px` : '640px';
  const mobileHeight = appearance?.hero_height
    ? `${Math.max(480, Math.min(560, appearance.hero_height - 120))}px`
    : '520px';

  const positionClass =
    position === 'top' ? 'center top' : position === 'bottom' ? 'center bottom' : 'center center';

  // Gradient overlay based on configured overlay intensity
  const overlayGradient = `linear-gradient(to bottom, rgba(18, 59, 104, ${overlayAlpha}) 0%, rgba(7, 86, 165, ${Math.max(
    0.15,
    overlayAlpha - 0.1
  )}) 45%, rgba(18, 59, 104, ${Math.min(0.85, overlayAlpha + 0.2)}) 100%)`;

  const hasImage = bgImage && bgImage !== 'none';

  return (
    <section
      id="home"
      className="relative w-full flex items-center justify-center text-center overflow-hidden transition-all duration-300"
      style={{
        minHeight: mobileHeight,
        height: desktopHeight,
        backgroundImage: hasImage
          ? `${overlayGradient}, url('${bgImage}')`
          : 'linear-gradient(135deg, #123B68 0%, #0756A5 55%, #0d2c4f 100%)',
        backgroundSize: displayMode,
        backgroundPosition: positionClass,
        backgroundRepeat: 'no-repeat',
        backgroundColor: '#123B68',
      }}
    >
      {/* Content wrapper with generous spacing */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 flex flex-col items-center">
        {/* HP Dealership Credibility Tag */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/30 text-white text-xs sm:text-sm font-bold uppercase tracking-wider mb-5 shadow-md">
          <ShieldCheck className="w-4 h-4 text-emerald-300" />
          <span>Hindustan Petroleum Authorized Retail Station</span>
        </div>

        {/* Central Bold Heading */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white tracking-tight leading-none uppercase drop-shadow-[0_4px_8px_rgba(0,0,0,0.6)]">
          Raj Petroleum
        </h1>

        {/* Professional Supporting Tagline */}
        <p className="mt-4 sm:mt-5 text-base sm:text-xl lg:text-2xl font-semibold text-slate-100 max-w-2xl leading-relaxed drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
          Purity in Every Drop, Accuracy in Every Dispenser. Serving Nandre and Miraj Highway Commuters 24 Hours a Day.
        </p>

        {/* Verified Location Marker */}
        <div className="mt-4 inline-flex items-center justify-center gap-2 px-3.5 py-1.5 rounded-lg bg-black/35 backdrop-blur-xs text-xs sm:text-sm font-medium text-slate-200 border border-white/15">
          <MapPin className="w-4 h-4 text-[#D62828] shrink-0" />
          <span>Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416</span>
        </div>

        {/* 3 Primary Action Buttons: Call Now, WhatsApp, Get Directions */}
        <div className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-3.5 sm:gap-4 md:gap-5">
          {/* 1. Call Now */}
          <a
            href={callHref}
            className="inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3.5 min-w-[150px] sm:min-w-[165px] rounded-lg bg-[#D62828] hover:bg-[#b81d1d] text-white text-xs sm:text-sm font-extrabold uppercase tracking-wider shadow-lg hover:shadow-xl transition-all transform active:scale-95"
          >
            <Phone className="w-4 h-4 shrink-0" />
            <span>Call Now</span>
          </a>

          {/* 2. WhatsApp */}
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3.5 min-w-[150px] sm:min-w-[165px] rounded-lg bg-[#25D366] hover:bg-[#20ba59] text-white text-xs sm:text-sm font-extrabold uppercase tracking-wider shadow-lg hover:shadow-xl transition-all transform active:scale-95"
          >
            <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
              <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
            </svg>
            <span>WhatsApp</span>
          </a>

          {/* 3. Get Directions */}
          <a
            href={directionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 sm:px-7 py-3.5 min-w-[150px] sm:min-w-[165px] rounded-lg bg-white hover:bg-slate-100 text-[#0756A5] text-xs sm:text-sm font-extrabold uppercase tracking-wider shadow-lg hover:shadow-xl transition-all transform active:scale-95"
          >
            <Navigation className="w-4 h-4 shrink-0" />
            <span>Get Directions</span>
          </a>
        </div>


        {/* Feature Highlights Strip */}
        <div className="mt-8 pt-6 border-t border-white/20 flex flex-wrap justify-center items-center gap-6 text-xs sm:text-sm font-medium text-slate-100 drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]">
          <span className="flex items-center gap-1.5 font-bold">
            <Clock className="w-4 h-4 text-emerald-300" /> Open 24/7
          </span>
          <span className="text-white/40">·</span>
          <span>100% Certified Density & Measure</span>
          <span className="text-white/40">·</span>
          <span>Digital Nitrogen Air Station</span>
        </div>
      </div>
    </section>
  );
};
