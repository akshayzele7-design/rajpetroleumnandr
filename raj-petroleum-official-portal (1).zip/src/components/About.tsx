import React from 'react';
import { ShieldCheck, UserCheck, MapPin, Award, CheckCircle2 } from 'lucide-react';
import { BusinessSettings } from '../types';

interface AboutProps {
  settings: BusinessSettings | null;
}

export const About: React.FC<AboutProps> = ({ settings }) => {
  const businessName = settings?.business_name || 'Raj Petroleum';
  const ownerName = settings?.owner_name || 'Sunita Patil';
  const address = settings?.address || 'Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India.';
  const plusCode = settings?.plus_code || 'WGXW+GXR';
  const description =
    settings?.description ||
    'Raj Petroleum is an authorized Hindustan Petroleum (HPCL) retail outlet located on Main Road in Nandre, Taluka Miraj, Sangli. Dedicated to uncompromising fuel purity, precise automated dispensing, and prompt, courteous hospitality for daily commuters and highway travelers.';

  return (
    <section id="about" className="py-16 bg-[#F3F6F9] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Story & Business Info */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
              <Award className="w-4 h-4 text-[#0756A5]" />
              <span>HPCL Dealership Credibility</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight leading-tight">
              About {businessName}
            </h2>
            <div className="w-16 h-1 bg-[#0756A5] mt-3 mb-6 rounded-full"></div>

            <p className="text-base text-slate-700 leading-relaxed">
              {description}
            </p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-white rounded-lg border border-slate-200/80 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-[#0756A5]">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 font-medium">Business Ownership</span>
                    <h4 className="text-sm font-bold text-slate-900">{ownerName}</h4>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-white rounded-lg border border-slate-200/80 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-[#0756A5]">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 font-medium">Retail Authorization</span>
                    <h4 className="text-sm font-bold text-slate-900">Hindustan Petroleum (HPCL)</h4>
                  </div>
                </div>
              </div>
            </div>

            {/* Core Commitments */}
            <div className="mt-6 space-y-2.5">
              <div className="flex items-start gap-2.5 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Automated multi-product dispensers with tamper-proof digital density meters.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Daily quantity and density testing recorded openly for customer verification.</span>
              </div>
              <div className="flex items-start gap-2.5 text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Clean drinking water and sanitized restrooms maintained 24 hours daily.</span>
              </div>
            </div>
          </div>

          {/* Right Column: Physical Details Card & Forecourt Visual */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 bg-white p-1 rounded-md border border-slate-200 flex items-center justify-center">
                  <img src="/assets/hp-logo.png" alt="HP Logo" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#123B68]">Verified Location Details</h3>
                  <span className="text-xs text-slate-500 font-medium">Miraj Taluka · Sangli District</span>
                </div>
              </div>

              <div className="space-y-4 text-sm text-slate-600 border-t border-slate-100 pt-4">
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Official Address
                  </span>
                  <p className="text-slate-800 leading-snug">{address}</p>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Plus Code
                    </span>
                    <span className="inline-block bg-[#F3F6F9] text-[#0756A5] font-mono text-xs px-2.5 py-1 rounded font-bold">
                      {plusCode}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Operating Hours
                    </span>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      24 Hours Open
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-slate-100">
                <a
                  href="#location"
                  className="w-full inline-flex items-center justify-center gap-2 text-xs font-bold text-[#0756A5] hover:text-[#123B68] py-2 bg-blue-50/70 hover:bg-blue-100/70 rounded transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  <span>View Map & Navigation Route</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
