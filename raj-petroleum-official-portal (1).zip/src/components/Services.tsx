import React from 'react';
import {
  Fuel,
  Zap,
  Gauge,
  Droplets,
  Sparkles,
  GlassWater,
  CreditCard,
  CheckCircle,
  ShieldCheck,
  HelpCircle,
  CheckCircle2,
} from 'lucide-react';
import { CustomerService } from '../types';

interface ServicesProps {
  services: CustomerService[];
  isLoading: boolean;
}

interface ServiceVisual {
  svg: React.ReactNode;
  emoji: string;
  bg: string;
  badgeBg: string;
  badgeLabel: string;
}

const getServiceVisuals = (title: string, iconName?: string): ServiceVisual => {
  const t = title.toLowerCase();
  const icon = (iconName || '').toLowerCase();

  // 1. HP Power Petrol
  if (t.includes('power') || icon === 'zap') {
    return {
      svg: <Zap className="w-6 h-6 text-[#0756A5]" />,
      emoji: '⚡',
      bg: 'bg-blue-50 text-[#0756A5] border-blue-150',
      badgeBg: 'bg-rose-50 text-[#D62828] border-rose-200/80',
      badgeLabel: 'Premium Grade',
    };
  }

  // 2. High-Speed Fuel Dispensing
  if (t.includes('dispens') || t.includes('fuel') || icon === 'fuel') {
    return {
      svg: <Fuel className="w-6 h-6 text-[#0756A5]" />,
      emoji: '⛽',
      bg: 'bg-blue-50 text-[#0756A5] border-blue-150',
      badgeBg: 'bg-blue-50 text-[#0756A5] border-blue-200/80',
      badgeLabel: '100% Accurate',
    };
  }

  // 3. Digital Air & Nitrogen Filling
  if (t.includes('air') || t.includes('nitrogen') || t.includes('tire') || icon === 'gauge' || icon === 'wind') {
    return {
      svg: <Gauge className="w-6 h-6 text-[#0756A5]" />,
      emoji: '🛞',
      bg: 'bg-sky-50 text-sky-700 border-sky-150',
      badgeBg: 'bg-sky-50 text-sky-700 border-sky-200/80',
      badgeLabel: 'Complimentary',
    };
  }

  // 4. Genuine HP Lubricants
  if (t.includes('lubricant') || t.includes('oil') || icon === 'droplets') {
    return {
      svg: <Droplets className="w-6 h-6 text-[#123B68]" />,
      emoji: '🛢️',
      bg: 'bg-indigo-50 text-[#123B68] border-indigo-150',
      badgeBg: 'bg-indigo-50 text-[#123B68] border-indigo-200/80',
      badgeLabel: 'Original Factory Pack',
    };
  }

  // 5. Restroom Facility
  if (t.includes('restroom') || t.includes('washroom') || t.includes('toilet') || icon === 'sparkles') {
    return {
      svg: <Sparkles className="w-6 h-6 text-teal-700" />,
      emoji: '🚻',
      bg: 'bg-teal-50 text-teal-700 border-teal-150',
      badgeBg: 'bg-teal-50 text-teal-700 border-teal-200/80',
      badgeLabel: 'Hygienic & Clean',
    };
  }

  // 6. Drinking Water Facility
  if (t.includes('water') || icon === 'glasswater') {
    return {
      svg: <GlassWater className="w-6 h-6 text-cyan-700" />,
      emoji: '💧',
      bg: 'bg-cyan-50 text-cyan-700 border-cyan-150',
      badgeBg: 'bg-cyan-50 text-cyan-700 border-cyan-200/80',
      badgeLabel: 'Free RO Purified',
    };
  }

  // 7. Digital & Fleet Payments
  if (t.includes('payment') || t.includes('card') || t.includes('upi') || icon === 'creditcard') {
    return {
      svg: <CreditCard className="w-6 h-6 text-[#0756A5]" />,
      emoji: '💳',
      bg: 'bg-emerald-50 text-emerald-700 border-emerald-150',
      badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200/80',
      badgeLabel: 'Contactless UPI',
    };
  }

  // General forecourt facility fallback
  return {
    svg: <ShieldCheck className="w-6 h-6 text-[#0756A5]" />,
    emoji: '⛽',
    bg: 'bg-blue-50 text-[#0756A5] border-blue-150',
    badgeBg: 'bg-blue-50 text-[#0756A5] border-blue-200/80',
    badgeLabel: 'Customer Service',
  };
};

export const Services: React.FC<ServicesProps> = ({ services, isLoading }) => {
  const activeServices = services.filter(
    (s) => s.is_active === undefined || Number(s.is_active) === 1 || s.is_active === true
  );

  return (
    <section id="services" className="py-16 bg-[#FFFDF7] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <CheckCircle className="w-4 h-4 text-[#0756A5]" />
            <span>Customer Facilities & Forecourt Amenities</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Customer Services
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600">
            Dedicated infrastructure designed to make every refueling stop comfortable, transparent, and seamless at Raj Petroleum.
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="h-56 bg-white rounded-2xl animate-pulse border border-slate-200"></div>
            ))}
          </div>
        ) : activeServices.length === 0 ? (
          <div className="text-center py-12 text-slate-500 max-w-md mx-auto">
            <HelpCircle className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-700 mb-1">No Active Facilities Found</h3>
            <p className="text-xs sm:text-sm text-slate-500">
              Service facilities are currently being updated by the station manager.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeServices.map((service) => {
              const customImageUrl =
                service.icon_image_url ||
                (service.icon_name && (service.icon_name.startsWith('/uploads/') || service.icon_name.startsWith('http'))
                  ? service.icon_name
                  : null);

              const visuals = getServiceVisuals(service.title, service.icon_name);

              return (
                <div
                  key={service.id}
                  className="group bg-white rounded-2xl border border-slate-200/90 hover:border-[#0756A5] p-6 sm:p-7 shadow-xs hover:shadow-md transition-all duration-200 hover:-translate-y-1 flex flex-col justify-between"
                >
                  <div>
                    {/* Top row: Icon container with subtle background & tag badge */}
                    <div className="flex items-center justify-between gap-3 mb-5">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${visuals.bg}`}>
                        {customImageUrl ? (
                          <img
                            src={customImageUrl}
                            alt={service.title}
                            className="w-full h-full object-cover rounded-xl"
                            onError={(e) => {
                              (e.currentTarget as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          visuals.svg
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-sm select-none" aria-hidden="true">
                          {visuals.emoji}
                        </span>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${visuals.badgeBg}`}
                        >
                          {visuals.badgeLabel}
                        </span>
                      </div>
                    </div>

                    {/* Deep Blue Heading */}
                    <h3 className="text-lg font-bold text-[#123B68] group-hover:text-[#0756A5] transition-colors tracking-tight">
                      {service.title}
                    </h3>

                    {/* Dark Grey Description */}
                    <p className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed font-normal">
                      {service.description}
                    </p>
                  </div>

                  {/* Card Footer: Verified Status in Green */}
                  <div className="mt-6 pt-3.5 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="inline-flex items-center gap-1.5 font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>Verified Station Facility</span>
                    </span>
                    <span className="text-slate-400 font-medium text-[11px]">
                      Available 24/7
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};


