import React from 'react';
import { Lock, MapPin, Phone, Mail, ShieldCheck } from 'lucide-react';
import { BusinessSettings, BrandingSettings } from '../types';

interface FooterProps {
  settings: BusinessSettings | null;
  branding?: BrandingSettings | null;
}

export const Footer: React.FC<FooterProps> = ({ settings, branding }) => {
  const currentYear = new Date().getFullYear();
  const businessName = branding?.brand_name || settings?.business_name || 'Raj Petroleum';
  const logoUrl = branding?.logo_url || '/assets/hp-logo.png';
  const address = settings?.address || 'Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India.';
  const phone = settings?.phone || '93721 47039';
  const whatsapp = settings?.whatsapp || '8766660414';
  const email = settings?.email || 'rajpetroleum.nandre@gmail.com';

  const cleanPhone = phone.replace(/\D/g, '');
  const cleanWhatsapp = whatsapp.replace(/\D/g, '');
  const callHref = `tel:${cleanPhone}`;
  const whatsappHref = `https://wa.me/91${cleanWhatsapp.slice(-10)}`;

  return (
    <footer className="bg-[#123B68] text-white">
      {/* Upper Main Footer Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* Col 1: Brand & Credibility */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white p-1 rounded-md flex items-center justify-center shrink-0">
                <img
                  src={logoUrl}
                  alt={`${businessName} Logo`}
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    const img = e.currentTarget as HTMLImageElement;
                    if (img.src !== window.location.origin + '/assets/hp-logo.png') {
                      img.src = '/assets/hp-logo.png';
                    }
                  }}
                />
              </div>
              <div>
                <h3 className="text-xl font-black tracking-tight text-white">{businessName}</h3>
                <span className="text-xs text-blue-200 font-semibold block">
                  Authorized HP Retail Outlet · Nandre, Sangli
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-blue-100 leading-relaxed max-w-sm">
              Providing certified high-density fuels, HP Power Petrol, genuine engine lubricants, and motorist amenities on Main Road, Nandre.
            </p>

            <div className="flex items-center gap-2 text-xs text-blue-200">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Certified Hindustan Petroleum Quality & Measure</span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-300">Quick Navigation</h4>
            <ul className="space-y-2 text-xs text-blue-100">
              <li>
                <a href="#home" className="hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="#fuel-price" className="hover:text-white transition-colors">Live Fuel Price</a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">About Us</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Customer Services</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">Station Gallery</a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-white transition-colors">Customer Reviews</a>
              </li>
              <li>
                <a href="#support" className="hover:text-white transition-colors">Business & Support</a>
              </li>
              <li>
                <a href="#location" className="hover:text-white transition-colors">Location & Directions</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Address Summary */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-300">Station Office</h4>
            <div className="space-y-2.5 text-xs text-blue-100">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-snug">{address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-rose-400 shrink-0" />
                <a href={callHref} className="tabular-nums hover:text-white transition-colors font-medium">
                  Call: {phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 text-[#25D366] shrink-0">
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
                  </svg>
                </div>
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="tabular-nums hover:text-[#25D366] transition-colors font-medium"
                >
                  WhatsApp: {whatsapp}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-300 shrink-0" />
                <a href={`mailto:${email}`} className="hover:text-white transition-colors">
                  {email}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>


      {/* Bottom Sub-footer */}
      <div className="border-t border-blue-900/80 bg-[#0d2c4f] py-4 px-4 sm:px-8 text-xs text-blue-200">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {currentYear} {businessName}. All rights reserved.</p>

          <div className="flex items-center gap-4">
            <span className="text-[11px] text-blue-300/80">Sangli District, Maharashtra</span>
            <span className="text-blue-400">·</span>
            {/* Only small, professional lock icon for admin entry */}
            <a
              href="/admin/login"
              className="p-1.5 text-blue-300/60 hover:text-white hover:bg-white/10 rounded transition-colors inline-flex items-center justify-center"
              aria-label="Dealer Login"
            >
              <Lock className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
