import React, { useState, useEffect } from 'react';
import { Megaphone, ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';
import { Announcement } from '../types';

interface AnnouncementBarProps {
  announcements: Announcement[];
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({ announcements }) => {
  const activeList = announcements.filter((a) => a.is_active === 1 || a.is_active === true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (activeList.length <= 1 || isPaused) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeList.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [activeList.length, isPaused]);

  if (activeList.length === 0) return null;

  const current = activeList[currentIndex] || activeList[0];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + activeList.length) % activeList.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % activeList.length);
  };

  return (
    <div
      className="bg-[#0756A5] text-[#FFFDF7] text-xs sm:text-sm font-medium border-b border-[#054483] relative z-40 transition-colors"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      role="region"
      aria-label="Important Announcements"
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 sm:py-2.5 flex items-center justify-between gap-3">
        {/* Left icon badge */}
        <div className="hidden xs:flex items-center gap-1.5 shrink-0 bg-[#054483] px-2 py-0.5 rounded text-[11px] uppercase tracking-wider font-bold text-amber-300">
          <Megaphone className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
          <span>Notice</span>
        </div>

        {/* Message content */}
        <div className="flex-1 text-center truncate px-1">
          {current.link_url ? (
            <a
              href={current.link_url}
              className="inline-flex items-center gap-1.5 hover:underline hover:text-white transition-colors"
            >
              <span className="truncate">{current.message}</span>
              <ExternalLink className="w-3 h-3 shrink-0 opacity-80" />
            </a>
          ) : (
            <span className="truncate">{current.message}</span>
          )}
        </div>

        {/* Right controls if multiple */}
        {activeList.length > 1 && (
          <div className="flex items-center gap-1 shrink-0">
            <span className="text-[11px] opacity-75 font-mono mr-1 hidden sm:inline">
              {currentIndex + 1}/{activeList.length}
            </span>
            <button
              onClick={handlePrev}
              aria-label="Previous announcement"
              className="p-1 hover:bg-[#054483] rounded transition-colors text-white/80 hover:text-white"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleNext}
              aria-label="Next announcement"
              className="p-1 hover:bg-[#054483] rounded transition-colors text-white/80 hover:text-white"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
