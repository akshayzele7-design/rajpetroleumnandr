import React from 'react';
import { MapPin, Navigation, Compass, ExternalLink, Phone } from 'lucide-react';
import { BusinessSettings } from '../types';

interface FindUsProps {
  settings: BusinessSettings | null;
}

export const FindUs: React.FC<FindUsProps> = ({ settings }) => {
  const address = settings?.address || 'Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India.';
  const plusCode = settings?.plus_code || 'WGXW+GXR';
  const phone = settings?.phone || '93721 47039';
  const whatsapp = settings?.whatsapp || '8766660414';

  const mapEmbedUrl =
    'https://maps.google.com/maps?q=Raj%20Petroleum%2C%20WGXW%2BGXR%2C%20Nandre%2C%20Miraj%2C%20Sangli%2C%20Maharashtra%20416416&t=&z=16&ie=UTF8&iwloc=&output=embed';

  const getDirectionsUrl =
    'https://www.google.com/maps/dir/?api=1&destination=Raj+Petroleum%2C+WGXW%2BGXR%2C+Nandre%2C+Miraj%2C+Sangli%2C+Maharashtra+416416';

  const viewOnMapsUrl =
    'https://www.google.com/maps/search/?api=1&query=Raj%20Petroleum%2C%20WGXW%2BGXR%2C%20Nandre%2C%20Miraj%2C%20Sangli%2C%20Maharashtra%20416416';

  const cleanPhone = phone.replace(/\D/g, '');
  const cleanWhatsapp = whatsapp.replace(/\D/g, '');
  const callHref = `tel:${cleanPhone}`;
  const whatsappHref = `https://wa.me/91${cleanWhatsapp.slice(-10)}`;

  return (
    <section id="location" className="py-16 bg-[#F3F6F9] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <Compass className="w-4 h-4 text-[#0756A5]" />
            <span>Interactive Highway Location</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Find Raj Petroleum
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600">
            Conveniently situated along Main Road in Nandre, Taluka Miraj, providing easy drive-in and drive-out access for two-wheelers, cars, tractors, and highway transit trucks.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Map Embed Container */}
          <div className="lg:col-span-8 bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-xs flex flex-col min-h-[420px]">
            <div className="p-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
              <span className="font-semibold flex items-center gap-1.5 text-[#0756A5]">
                <MapPin className="w-4 h-4 text-[#D62828]" />
                <span>Google Maps · Raj Petroleum (WGXW+GXR, Nandre)</span>
              </span>
              <div className="flex items-center gap-3">
                <a
                  href={viewOnMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-bold text-[#0756A5] hover:text-[#123B68] flex items-center gap-1"
                >
                  <span>View on Google Maps</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="relative flex-1 w-full min-h-[380px] bg-slate-100">
              <iframe
                title="Raj Petroleum Location Map"
                src={mapEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '380px' }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              ></iframe>
            </div>
          </div>

          {/* Location Details & Actions Column */}
          <div className="lg:col-span-4 bg-white rounded-2xl p-6 sm:p-7 border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                  Open 24/7 on Main Road
                </span>
              </div>

              <h3 className="text-xl font-extrabold text-[#123B68]">
                Raj Petroleum
              </h3>
              <span className="text-xs text-slate-500 font-semibold block mb-4">
                Authorized Hindustan Petroleum Dealer · Nandre
              </span>

              <div className="space-y-4 text-sm text-slate-700">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-5 h-5 text-[#D62828] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase block mb-0.5">
                      Physical Address
                    </span>
                    <p className="leading-snug">{address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Compass className="w-5 h-5 text-[#0756A5] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase block mb-0.5">
                      Google Maps Plus Code
                    </span>
                    <span className="font-mono text-xs font-bold text-[#0756A5] bg-[#F3F6F9] px-2.5 py-1 rounded border border-slate-200 inline-block">
                      {plusCode}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <Phone className="w-5 h-5 text-[#D62828] shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase block mb-0.5">
                      Call Number
                    </span>
                    <a
                      href={callHref}
                      className="font-bold text-slate-900 hover:text-[#0756A5] transition-colors tabular-nums text-sm block"
                    >
                      {phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <div className="w-5 h-5 text-[#25D366] shrink-0 mt-0.5">
                    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                      <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
                    </svg>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase block mb-0.5">
                      WhatsApp Number
                    </span>
                    <a
                      href={whatsappHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-bold text-slate-900 hover:text-emerald-600 transition-colors tabular-nums text-sm block"
                    >
                      {whatsapp}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-slate-100 flex flex-col gap-2.5">
              <a
                href={getDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider shadow-sm hover:shadow transition-all"
              >
                <Navigation className="w-4 h-4" />
                <span>Get Directions</span>
              </a>

              <a
                href={viewOnMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#0756A5]" />
                <span>View on Google Maps</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );

};
