import React, { useState } from 'react';
import { Image as ImageIcon, X, Maximize2, Camera } from 'lucide-react';
import { GalleryImage } from '../types';

interface GalleryProps {
  images: GalleryImage[];
  isLoading: boolean;
}

export const Gallery: React.FC<GalleryProps> = ({ images, isLoading }) => {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

  const activeImages = images.filter(
    (img) => img.is_active === undefined || Number(img.is_active) === 1 || img.is_active === true
  );


  return (
    <section id="gallery" className="py-16 bg-[#F3F6F9] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <Camera className="w-4 h-4 text-[#0756A5]" />
            <span>Forecourt & Station Infrastructure</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Station Gallery
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600">
            High-standard facilities, automated dispensers, and clean landscaped surroundings at Raj Petroleum.
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-64 bg-slate-200 rounded-xl animate-pulse"></div>
            ))}
          </div>
        ) : activeImages.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <ImageIcon className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <p className="text-sm">Station gallery photographs will be uploaded soon.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeImages.map((img) => (
              <div
                key={img.id}
                className="group relative bg-white rounded-xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col"
              >
                <div
                  className="relative h-60 w-full overflow-hidden cursor-pointer bg-slate-100 flex items-center justify-center"
                  onClick={() => setSelectedImage(img)}
                >
                  <img
                    src={img.image_url}
                    alt={img.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                    onError={(e) => {
                      // Fallback icon container if image fails to load
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      const parent = target.parentElement;
                      if (parent) {
                        parent.classList.add('bg-slate-200', 'flex', 'items-center', 'justify-center');
                        parent.innerHTML = `<span class="text-xs font-semibold text-slate-500">Raj Petroleum Visual</span>`;
                      }
                    }}
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="p-2 bg-white/90 text-slate-900 rounded-full shadow-sm">
                      <Maximize2 className="w-4 h-4" />
                    </span>
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 line-clamp-1">{img.title}</h3>
                    {img.description && (
                      <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                        {img.description}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal Lightbox Preview */}
        {selectedImage && (
          <div
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div
              className="relative max-w-4xl w-full bg-white rounded-xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-3 right-3 z-10 p-2 bg-black/60 hover:bg-black text-white rounded-full transition-colors"
                aria-label="Close image preview"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="max-h-[75vh] bg-slate-950 flex items-center justify-center overflow-hidden">
                <img
                  src={selectedImage.image_url}
                  alt={selectedImage.title}
                  className="max-h-[75vh] w-auto object-contain"
                />
              </div>

              <div className="p-5 bg-white border-t border-slate-200">
                <h3 className="text-lg font-bold text-[#123B68]">{selectedImage.title}</h3>
                {selectedImage.description && (
                  <p className="text-xs sm:text-sm text-slate-600 mt-1">{selectedImage.description}</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
