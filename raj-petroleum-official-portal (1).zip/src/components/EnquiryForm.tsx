import React, { useState } from 'react';
import {
  Phone,
  Send,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Copy,
  Check,
  Building2,
  Mail,
  User,
  FileText,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { submitPublicEnquiry } from '../api';
import { BusinessSettings } from '../types';

const ENQUIRY_CATEGORIES = [
  'General Enquiry',
  'Customer Support',
  'Feedback or Complaint',
  'Business Enquiry',
  'Bulk Fuel Supply (Diesel / Petrol)',
  'Commercial & Fleet Accounts (HP DriveTrack Plus)',
  'Agricultural Machinery Fueling',
  'Industrial Lubricants & Oils',
  'Dealership & Partnership Enquiry',
  'Billing & Invoice Queries',
  'Other',
];

interface EnquiryFormProps {
  settings?: BusinessSettings | null;
}

export const EnquiryForm: React.FC<EnquiryFormProps> = ({ settings }) => {
  const [customerName, setCustomerName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState(ENQUIRY_CATEGORIES[0]);
  const [organization, setOrganization] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successInfo, setSuccessInfo] = useState<{ message: string; referenceNo: string } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedRef, setCopiedRef] = useState(false);

  const callNumber = settings?.phone || '93721 47039';
  const whatsappNumber = settings?.whatsapp || '8766660414';
  const cleanPhone = callNumber.replace(/\D/g, '');
  const cleanWhatsapp = whatsappNumber.replace(/\D/g, '');
  const callHref = `tel:${cleanPhone}`;
  const whatsappHref = `https://wa.me/91${cleanWhatsapp.slice(-10)}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !mobileNumber.trim() || !category || !subject.trim() || !message.trim()) {
      setErrorMsg('Please complete all required fields.');
      return;
    }

    // Basic mobile number validation (at least 10 digits)
    const digitsOnly = mobileNumber.replace(/\D/g, '');
    if (digitsOnly.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile phone number.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const res = await submitPublicEnquiry({
        customer_name: customerName,
        mobile_number: mobileNumber,
        email: email.trim() || undefined,
        category,
        organization: organization.trim() || undefined,
        subject,
        message,
      });

      setSuccessInfo({
        message: res.message || 'Thank you for contacting Raj Petroleum. Your request has been submitted successfully.',
        referenceNo: res.reference_no,
      });

      // Clear input fields
      setCustomerName('');
      setMobileNumber('');
      setEmail('');
      setCategory(ENQUIRY_CATEGORIES[0]);
      setOrganization('');
      setSubject('');
      setMessage('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit enquiry. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyReference = (ref: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(ref);
      setCopiedRef(true);
      setTimeout(() => setCopiedRef(false), 2500);
    }
  };

  return (
    <section id="support" className="relative py-16 bg-white border-b border-slate-200">
      {/* Anchor alias so #enquiry still scrolls here */}
      <span id="enquiry" className="absolute -top-20"></span>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <HelpCircle className="w-4 h-4 text-[#0756A5]" />
            <span>Dedicated Assistance & Inquiries</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Business & Customer Support
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Have a business enquiry, need assistance, or have a question about our services? Connect with Raj Petroleum. We are here to assist you.
          </p>
        </div>

        {/* Quick Contact Action Banner (Call Now & Chat on WhatsApp) */}
        <div className="mb-10 bg-gradient-to-r from-[#123B68] via-[#0756A5] to-[#123B68] rounded-2xl p-5 sm:p-6 text-white shadow-md flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-center md:text-left">
            <span className="text-[11px] font-bold uppercase tracking-wider text-blue-200 block mb-0.5">
              Direct Station Lines
            </span>
            <h3 className="text-lg sm:text-xl font-black">
              Need Instant Fuel Dispatch or On-Site Help?
            </h3>
            <p className="text-xs text-blue-100 mt-1 max-w-lg">
              Call our forecourt desk or chat directly on WhatsApp for real-time rates and fleet queries.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
            {/* Call Now */}
            <a
              href={callHref}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#D62828] hover:bg-[#b81d1d] text-white text-xs font-extrabold uppercase tracking-wider shadow-sm hover:shadow transition-all transform active:scale-95"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Now: {callNumber}</span>
            </a>

            {/* Chat on WhatsApp */}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-extrabold uppercase tracking-wider shadow-sm hover:shadow transition-all transform active:scale-95"
            >
              <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
              </svg>
              <span>Chat on WhatsApp: {whatsappNumber}</span>
            </a>
          </div>
        </div>

        {/* Form Container */}
        <div className="bg-[#F3F6F9] p-6 sm:p-10 rounded-2xl border border-slate-200 shadow-sm">
          {/* Success Notification with Reference Number */}
          {successInfo && (
            <div className="mb-8 p-5 bg-emerald-50 border-2 border-emerald-300 text-emerald-950 rounded-xl shadow-xs">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <h4 className="text-sm sm:text-base font-extrabold text-emerald-900">
                    Request Submitted Successfully
                  </h4>
                  <p className="text-xs sm:text-sm text-emerald-800 mt-1 font-medium">
                    {successInfo.message}
                  </p>

                  <div className="mt-3.5 pt-3 border-t border-emerald-200/80 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                        Your Unique Reference Number:
                      </span>
                      <span className="font-mono text-sm font-extrabold text-[#0756A5] bg-white px-3 py-1 rounded-md border border-emerald-200 shadow-2xs">
                        {successInfo.referenceNo}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopyReference(successInfo.referenceNo)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-bold rounded shadow-2xs cursor-pointer transition-colors"
                    >
                      {copiedRef ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Copy Reference</span>
                        </>
                      )}
                    </button>
                  </div>

                  <p className="text-[11px] text-emerald-700/90 mt-2">
                    Please retain this reference number for follow-up correspondence with our management desk.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Error Notification */}
          {errorMsg && (
            <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <p className="text-xs font-semibold">{errorMsg}</p>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Row 1: Full Name & Mobile Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="support-name" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  1. Full Name <span className="text-[#D62828]">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="support-name"
                    type="text"
                    required
                    placeholder="e.g. Ramesh Patil"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="support-mobile" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  2. Mobile Number <span className="text-[#D62828]">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    id="support-mobile"
                    type="tel"
                    required
                    placeholder="e.g. 98220 12345"
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Row 2: Email & Enquiry Type / Category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="support-email" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  3. Email Address <span className="text-slate-400 font-normal lowercase">(optional)</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="support-email"
                    type="email"
                    placeholder="e.g. name@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="support-category" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  4. Enquiry Type / Category <span className="text-[#D62828]">*</span>
                </label>
                <select
                  id="support-category"
                  required
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors cursor-pointer font-medium text-slate-800"
                >
                  {ENQUIRY_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 3: Optional Organization & Required Subject */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="support-org" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  5. Organization / Farm / Business Name <span className="text-slate-400 font-normal lowercase">(optional)</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <input
                    id="support-org"
                    type="text"
                    placeholder="e.g. Patil Agro Logistics / Nandre Transports"
                    value={organization}
                    onChange={(e) => setOrganization(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="support-subject" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  6. Subject <span className="text-[#D62828]">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <input
                    id="support-subject"
                    type="text"
                    required
                    placeholder="e.g. Bulk High-Speed Diesel supply arrangement"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Row 4: Message */}
            <div>
              <label htmlFor="support-message" className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                7. Message & Specific Requirements <span className="text-[#D62828]">*</span>
              </label>
              <div className="relative">
                <textarea
                  id="support-message"
                  rows={4}
                  required
                  placeholder="Please describe your requirements, fleet volume, vehicle type, or specific question in detail..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-4 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:ring-1 focus:ring-[#0756A5] transition-colors"
                ></textarea>
              </div>
            </div>

            {/* Submit Row */}
            <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <span className="text-[11px] text-slate-500 max-w-md">
                Your submitted details are strictly confidential and forwarded directly to the station management desk for official follow-up.
              </span>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-extrabold uppercase tracking-wider rounded-lg shadow-sm hover:shadow transition-all disabled:opacity-50 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Submitting Request...' : 'Submit Request'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
