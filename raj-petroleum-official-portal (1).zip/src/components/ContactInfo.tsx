import React from 'react';
import { Phone, Mail, Clock, MapPin, User, Headphones } from 'lucide-react';
import { BusinessSettings } from '../types';

interface ContactInfoProps {
  settings: BusinessSettings | null;
}

export const ContactInfo: React.FC<ContactInfoProps> = ({ settings }) => {
  const businessName = settings?.business_name || 'Raj Petroleum';
  const ownerName = settings?.owner_name || 'Sunita Patil';
  const address = settings?.address || 'Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India.';
  const phone = settings?.phone || '93721 47039';
  const whatsapp = settings?.whatsapp || '8766660414';
  const email = settings?.email || 'rajpetroleum.nandre@gmail.com';
  const openingHours = settings?.opening_hours || 'Open 24 Hours / 7 Days a Week';

  const cleanPhone = phone.replace(/\D/g, '');
  const cleanWhatsapp = whatsapp.replace(/\D/g, '');
  const callHref = `tel:${cleanPhone}`;
  const whatsappHref = `https://wa.me/91${cleanWhatsapp.slice(-10)}`;

  return (
    <section id="contact" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <Headphones className="w-4 h-4 text-[#0756A5]" />
            <span>Direct Business Communication</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            Official Contact Information
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600">
            Reach out to our management team for corporate fleet arrangements, bulk fuel requirements, or forecourt assistance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Card 1: Call Helpline */}
          <div className="p-6 bg-[#FFFDF7] rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-rose-50 text-[#D62828] flex items-center justify-center mb-4">
                <Phone className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Call Number
              </span>
              <a
                href={callHref}
                className="text-base font-extrabold text-[#123B68] hover:text-[#D62828] transition-colors tabular-nums block"
              >
                {phone}
              </a>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-xs text-slate-500">Forecourt Helpline</span>
              <a
                href={callHref}
                className="text-xs font-bold text-[#D62828] hover:underline inline-flex items-center gap-1"
              >
                Call Now →
              </a>
            </div>
          </div>

          {/* Card 2: WhatsApp Chat */}
          <div className="p-6 bg-[#FFFDF7] rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-emerald-50 text-[#25D366] flex items-center justify-center mb-4">
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
                </svg>
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                WhatsApp Number
              </span>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="text-base font-extrabold text-[#123B68] hover:text-[#25D366] transition-colors tabular-nums block"
              >
                {whatsapp}
              </a>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-xs text-slate-500">Instant Chat</span>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-bold text-emerald-600 hover:underline inline-flex items-center gap-1"
              >
                Chat on WhatsApp →
              </a>
            </div>
          </div>

          {/* Card 3: Opening Hours */}
          <div className="p-6 bg-[#FFFDF7] rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0756A5] flex items-center justify-center mb-4">
                <Clock className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Station Timings
              </span>
              <span className="text-sm font-extrabold text-slate-900 block">
                {openingHours}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-4 pt-3 border-t border-slate-200/60">
              Continuous 24-hour retail and emergency refueling.
            </p>
          </div>

          {/* Card 4: Proprietor & Management */}
          <div className="p-6 bg-[#FFFDF7] rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0756A5] flex items-center justify-center mb-4">
                <User className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Station Proprietor
              </span>
              <span className="text-sm font-extrabold text-slate-900 block">
                {ownerName}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-4 pt-3 border-t border-slate-200/60">
              Authorized Hindustan Petroleum Dealership.
            </p>
          </div>
        </div>
      </div>
    </section>
  );

};
