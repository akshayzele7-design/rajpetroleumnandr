import React from 'react';
import {
  CreditCard,
  QrCode,
  Wallet,
  Gift,
  Flame,
  MapPin,
  ExternalLink,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  Download,
  Info,
} from 'lucide-react';
import { HpPaySectionData } from '../types';

interface HpPaySectionProps {
  hpPay: HpPaySectionData | null;
}

const featureIconMap: Record<string, React.ReactNode> = {
  CreditCard: <CreditCard className="w-5 h-5 text-[#0756A5]" />,
  QrCode: <QrCode className="w-5 h-5 text-[#0756A5]" />,
  Wallet: <Wallet className="w-5 h-5 text-[#0756A5]" />,
  Gift: <Gift className="w-5 h-5 text-[#0756A5]" />,
  Flame: <Flame className="w-5 h-5 text-[#D62828]" />,
  MapPin: <MapPin className="w-5 h-5 text-[#0756A5]" />,
  Smartphone: <Smartphone className="w-5 h-5 text-[#0756A5]" />,
  ShieldCheck: <ShieldCheck className="w-5 h-5 text-emerald-600" />,
};

export const HpPaySection: React.FC<HpPaySectionProps> = ({ hpPay }) => {
  if (!hpPay) return null;
  const isVisible = hpPay.is_visible !== 0 && hpPay.is_visible !== false;
  const isDeleted = hpPay.is_deleted === 1 || hpPay.is_deleted === true;

  if (!isVisible || isDeleted) {
    return null;
  }

  const sectionTitle = hpPay.title || 'HP Pay App';
  const heading = hpPay.heading || 'Discover HP Pay';
  const description =
    hpPay.description ||
    "HP Pay is a digital payment and convenience application from Hindustan Petroleum Corporation Limited (HPCL). Explore the app's supported fuel payment options, digital payment features, rewards, and other available services.";
  const appIcon = hpPay.app_icon_url || '/assets/hp-pay-logo.png';
  const playStoreUrl =
    hpPay.play_store_url || 'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel';
  const learnMoreUrl =
    hpPay.learn_more_url || 'https://www.hindustanpetroleum.com/pages/mobile-app';

  const features = Array.isArray(hpPay.features) && hpPay.features.length > 0 ? hpPay.features : [];

  return (
    <section id="hp-pay" className="py-16 bg-[#F3F6F9] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0756A5] uppercase tracking-wider mb-2">
            <span className="w-2 h-2 rounded-full bg-[#D62828]"></span>
            <span>{sectionTitle}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#123B68] tracking-tight">
            {heading}
          </h2>
          <div className="w-16 h-1 bg-[#0756A5] mx-auto mt-3 mb-4 rounded-full"></div>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            {description}
          </p>
        </div>

        {/* Featured Showcase Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 lg:p-10 mb-10 overflow-hidden relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: App Identity, Official Icon & Actions */}
            <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left">
              <div className="flex items-center gap-4 sm:gap-5 mb-5">
                {/* Genuine App Icon */}
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border border-slate-200 shadow-md shrink-0 bg-white p-1">
                  <img
                    src={appIcon}
                    alt="HP Pay Official App Icon"
                    className="w-full h-full object-contain rounded-xl"
                    onError={(e) => {
                      const img = e.currentTarget as HTMLImageElement;
                      if (img.src !== window.location.origin + '/assets/hp-pay-logo.png') {
                        img.src = '/assets/hp-pay-logo.png';
                      }
                    }}
                  />
                </div>

                <div>
                  <div className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full mb-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Official HPCL App</span>
                  </div>
                  <h3 className="text-2xl font-black text-[#123B68] tracking-tight">
                    HP Pay
                  </h3>
                  <p className="text-xs font-semibold text-slate-500">
                    Hindustan Petroleum Corp. Ltd.
                  </p>
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                Refuel with touchless ease at Raj Petroleum. Earn reward points on every litre, pay instantly with dynamic QR, and manage your vehicle fueling expenses effortlessly.
              </p>

              {/* Working Action Buttons */}
              <div className="w-full flex flex-col sm:flex-row items-center gap-3">
                {/* 1. Download HP Pay on Google Play */}
                <a
                  href={playStoreUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2.5 px-5 py-3 rounded-xl bg-[#123B68] hover:bg-[#0756A5] text-white text-xs font-extrabold uppercase tracking-wider shadow-md hover:shadow-lg transition-all transform active:scale-95"
                >
                  <Download className="w-4 h-4 text-[#D62828] shrink-0" />
                  <span>Download on Google Play</span>
                  <ExternalLink className="w-3 h-3 text-blue-200 shrink-0" />
                </a>

                {/* 2. Learn More */}
                <a
                  href={learnMoreUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#0756A5] text-xs font-bold uppercase tracking-wider border border-slate-200 transition-colors"
                >
                  <Info className="w-3.5 h-3.5 shrink-0" />
                  <span>Learn More</span>
                  <ExternalLink className="w-3 h-3 text-slate-400 shrink-0" />
                </a>
              </div>
            </div>

            {/* Right: Grid of Verified Features */}
            <div className="lg:col-span-7">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {features.map((feat) => {
                  const iconElement = featureIconMap[feat.icon] || (
                    <CheckCircle2 className="w-5 h-5 text-[#0756A5]" />
                  );
                  return (
                    <div
                      key={feat.id}
                      className="p-4 rounded-xl border border-slate-200/80 bg-[#FFFDF7] hover:border-[#0756A5] transition-all duration-150 flex flex-col justify-between"
                    >
                      <div>
                        <div className="w-9 h-9 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center mb-2.5 shrink-0">
                          {iconElement}
                        </div>
                        <h4 className="text-sm font-bold text-[#123B68] tracking-tight mb-1">
                          {feat.title}
                        </h4>
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {feat.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Clear Identification & Legal Disclaimer */}
        <div className="text-center max-w-2xl mx-auto text-xs text-slate-500 flex items-center justify-center gap-2">
          <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span>
            HP Pay is an official mobile application of Hindustan Petroleum Corporation Limited (HPCL). Raj Petroleum is an authorized retail outlet accepting HP Pay transactions.
          </span>
        </div>
      </div>
    </section>
  );
};
