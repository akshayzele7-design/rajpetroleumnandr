import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Fuel,
  Info,
  Wrench,
  Camera,
  Image as ImageIcon,
  MessageSquare,
  Star,
  Mail,
  Settings,
  Key,
  LogOut,
  Plus,
  Pencil,
  Trash2,
  CheckCircle,
  AlertCircle,
  RefreshCw,
  ExternalLink,
  Upload,
  Check,
  Clock,
  Sliders,
  RotateCcw,
  Eye,
  Megaphone,
  Palette,
  Headphones,
  Copy,
  Search,
  Building2,
  Phone,
  Filter,
  Smartphone,
  Download,
  Globe,
  QrCode,
  Wallet,
  Gift,
  Flame,
} from 'lucide-react';

import {
  authStorage,
  checkAdminSession,
  adminLogout,
  fetchAdminStats,
  fetchAdminSettings,
  updateAdminSettings,
  fetchAdminAppearance,
  updateAdminAppearance,
  uploadAppearanceBackground,
  deleteAppearanceBackground,
  fetchAdminFuelPrices,
  createFuelCategory,
  updateFuelCategory,
  deleteFuelCategory,
  fetchAdminServices,
  createCustomerService,
  updateCustomerService,
  deleteCustomerService,
  fetchAdminGallery,
  uploadGalleryFile,
  createGalleryImage,
  updateGalleryImage,
  deleteGalleryImage,
  fetchAdminFeedback,
  updateFeedbackStatus,
  deleteFeedbackSubmission,
  fetchAdminEnquiries,
  updateEnquiryStatus,
  deleteEnquiry,
  changeAdminPassword,
  fetchAdminAnnouncements,
  createAdminAnnouncement,
  updateAdminAnnouncement,
  deleteAdminAnnouncement,
  fetchAdminBranding,
  updateAdminBranding,
  uploadAdminLogo,
  deleteAdminLogo,
  uploadServiceIcon,
} from '../api';
import {
  DashboardStats,
  BusinessSettings,
  HomepageAppearance,
  FuelCategory,
  CustomerService,
  GalleryImage,
  FeedbackSubmission,
  CustomerEnquiry,
  Announcement,
  BrandingSettings,
} from '../types';

type AdminTab =
  | 'overview'
  | 'fuel'
  | 'about'
  | 'services'
  | 'gallery'
  | 'announcements'
  | 'branding'
  | 'appearance'
  | 'feedback'
  | 'reviews'
  | 'enquiries'
  | 'settings'
  | 'password';

export const AdminDashboardPage: React.FC = () => {
  const navigate = useNavigate();

  // Authentication check
  useEffect(() => {
    if (!authStorage.isAuthenticated()) {
      navigate('/admin/login');
      return;
    }
    checkAdminSession().then((isValid) => {
      if (!isValid) {
        authStorage.clearToken();
        navigate('/admin/login');
      }
    });
  }, [navigate]);

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [settings, setSettings] = useState<BusinessSettings | null>(null);
  const [appearance, setAppearance] = useState<HomepageAppearance | null>(null);
  const [branding, setBranding] = useState<BrandingSettings | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [fuelPrices, setFuelPrices] = useState<FuelCategory[]>([]);
  const [services, setServices] = useState<CustomerService[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [feedback, setFeedback] = useState<FeedbackSubmission[]>([]);
  const [enquiries, setEnquiries] = useState<CustomerEnquiry[]>([]);

  // Business & Customer Support Enquiries State
  const [enquirySearch, setEnquirySearch] = useState('');
  const [enquiryCategoryFilter, setEnquiryCategoryFilter] = useState('ALL');
  const [enquiryStatusFilter, setEnquiryStatusFilter] = useState('ALL');
  const [detailModalEnquiry, setDetailModalEnquiry] = useState<CustomerEnquiry | null>(null);
  const [detailStatus, setDetailStatus] = useState<CustomerEnquiry['status']>('New');
  const [detailNotes, setDetailNotes] = useState('');
  const [isSavingEnquiryDetail, setIsSavingEnquiryDetail] = useState(false);
  const [copiedRefId, setCopiedRefId] = useState<string | null>(null);


  // Announcements modal state
  const [announcementModal, setAnnouncementModal] = useState<{
    open: boolean;
    item: Partial<Announcement> | null;
  }>({ open: false, item: null });

  // Branding Form State
  const [brandingForm, setBrandingForm] = useState<BrandingSettings>({
    logo_url: '/assets/hp-logo.png',
    logo_height: 56,
    brand_name: 'RAJ PETROLEUM',
    tagline: 'Hindustan Petroleum Retail Outlet',
  });
  const [logoUploadFile, setLogoUploadFile] = useState<File | null>(null);
  const [isSavingBranding, setIsSavingBranding] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  // Service custom icon upload state
  const [serviceIconFile, setServiceIconFile] = useState<File | null>(null);
  const [isUploadingServiceIcon, setIsUploadingServiceIcon] = useState(false);

  // Appearance Form State
  const [appearanceForm, setAppearanceForm] = useState<HomepageAppearance>({
    background_image: '/assets/raj-petroleum-hero.jpg',
    position: 'center',
    display_mode: 'cover',
    overlay_intensity: 0.45,
    hero_height: 640,
  });
  const [bgUploadFile, setBgUploadFile] = useState<File | null>(null);
  const [isUploadingBg, setIsUploadingBg] = useState(false);
  const [isSavingAppearance, setIsSavingAppearance] = useState(false);

  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Modals & Confirmation States
  const [fuelModal, setFuelModal] = useState<{ open: boolean; item: Partial<FuelCategory> | null }>({
    open: false,
    item: null,
  });
  const [serviceModal, setServiceModal] = useState<{ open: boolean; item: Partial<CustomerService> | null }>({
    open: false,
    item: null,
  });
  const [galleryModal, setGalleryModal] = useState<{ open: boolean; item: Partial<GalleryImage> | null }>({
    open: false,
    item: null,
  });
  const [confirmDelete, setConfirmDelete] = useState<{
    open: boolean;
    title: string;
    description?: string;
    onConfirm: () => Promise<void>;
  }>({
    open: false,
    title: '',
    onConfirm: async () => {},
  });

  // Password state
  const [pwdCurrent, setPwdCurrent] = useState('');
  const [pwdNew, setPwdNew] = useState('');
  const [pwdConfirm, setPwdConfirm] = useState('');

  // Gallery upload state
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const showToast = (type: 'success' | 'error', message: string) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4000);
  };

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [st, set, app, fp, srv, gal, fb, enq, ann, brnd] = await Promise.all([
        fetchAdminStats(),
        fetchAdminSettings(),
        fetchAdminAppearance(),
        fetchAdminFuelPrices(),
        fetchAdminServices(),
        fetchAdminGallery(),
        fetchAdminFeedback(),
        fetchAdminEnquiries(),
        fetchAdminAnnouncements(),
        fetchAdminBranding(),
      ]);
      setStats(st);
      setSettings(set);
      setAppearance(app);
      setAppearanceForm(app);
      setFuelPrices(fp);
      setServices(srv);
      setGallery(gal);
      setFeedback(fb);
      setEnquiries(enq);
      setAnnouncements(ann);
      setBranding(brnd);
      setBrandingForm(brnd);
    } catch (err: any) {
      showToast('error', err.message || 'Failed to refresh data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const handleLogout = async () => {
    await adminLogout();
    navigate('/admin/login');
  };

  // ---------------------------------------------------------------------------
  // APPEARANCE OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveAppearance = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingAppearance(true);
    try {
      let finalBgUrl = appearanceForm.background_image;

      // Handle file upload if selected
      if (bgUploadFile) {
        setIsUploadingBg(true);
        finalBgUrl = await uploadAppearanceBackground(bgUploadFile);
        setIsUploadingBg(false);
        setBgUploadFile(null);
      }

      await updateAdminAppearance({
        ...appearanceForm,
        background_image: finalBgUrl,
      });

      showToast('success', 'Homepage appearance saved and live on the website.');
      loadAll();
    } catch (err: any) {
      setIsUploadingBg(false);
      showToast('error', err.message || 'Failed to update appearance.');
    } finally {
      setIsSavingAppearance(false);
    }
  };

  const handleDeleteBgImage = () => {
    setConfirmDelete({
      open: true,
      title: 'Delete Homepage Background Image?',
      description:
        'This will remove the current background image reference. The homepage will gracefully fallback to the verified default pump background or clean branded layout.',
      onConfirm: async () => {
        try {
          await deleteAppearanceBackground();
          setBgUploadFile(null);
          showToast('success', 'Background image reset to default.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message || 'Failed to reset background image.');
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // FUEL OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveFuel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fuelModal.item?.name?.trim()) {
      showToast('error', 'Category name is required.');
      return;
    }

    try {
      if (fuelModal.item.id) {
        await updateFuelCategory(fuelModal.item.id, fuelModal.item);
        showToast('success', 'Fuel category updated successfully.');
      } else {
        await createFuelCategory(fuelModal.item);
        showToast('success', 'Fuel category created successfully.');
      }
      setFuelModal({ open: false, item: null });
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleDeleteFuel = (fuel: FuelCategory) => {
    setConfirmDelete({
      open: true,
      title: `Delete fuel category "${fuel.name}"?`,
      onConfirm: async () => {
        try {
          await deleteFuelCategory(fuel.id);
          showToast('success', 'Fuel category deleted.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // SERVICES OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceModal.item?.title?.trim()) {
      showToast('error', 'Service title is required.');
      return;
    }

    try {
      let iconImageUrl = serviceModal.item.icon_image_url;
      if (serviceIconFile) {
        setIsUploadingServiceIcon(true);
        iconImageUrl = await uploadServiceIcon(serviceIconFile);
        setIsUploadingServiceIcon(false);
        setServiceIconFile(null);
      }

      const payload = {
        ...serviceModal.item,
        icon_image_url: iconImageUrl,
      };

      if (serviceModal.item.id) {
        await updateCustomerService(serviceModal.item.id, payload);
        showToast('success', 'Customer service updated.');
      } else {
        await createCustomerService(payload);
        showToast('success', 'Customer service added.');
      }
      setServiceModal({ open: false, item: null });
      loadAll();
    } catch (err: any) {
      setIsUploadingServiceIcon(false);
      showToast('error', err.message);
    }
  };

  const handleToggleServiceActive = async (service: CustomerService) => {
    try {
      const nextActive = service.is_active === 1 || service.is_active === true ? 0 : 1;
      await updateCustomerService(service.id, {
        ...service,
        is_active: nextActive,
      });
      showToast('success', `Service "${service.title}" is now ${nextActive ? 'Active' : 'Disabled'}.`);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleDeleteService = (service: CustomerService) => {
    setConfirmDelete({
      open: true,
      title: `Delete service "${service.title}"?`,
      onConfirm: async () => {
        try {
          await deleteCustomerService(service.id);
          showToast('success', 'Service removed.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // GALLERY OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let finalUrl = galleryModal.item?.image_url;

      if (uploadFile) {
        setIsUploading(true);
        finalUrl = await uploadGalleryFile(uploadFile);
        setIsUploading(false);
      }

      if (!finalUrl || !finalUrl.trim()) {
        showToast('error', 'Please provide an image URL or choose a file to upload.');
        return;
      }

      const payload = {
        ...galleryModal.item,
        image_url: finalUrl,
      };

      if (galleryModal.item?.id) {
        await updateGalleryImage(galleryModal.item.id, payload);
        showToast('success', 'Gallery image updated.');
      } else {
        await createGalleryImage(payload);
        showToast('success', 'Gallery image added.');
      }

      setGalleryModal({ open: false, item: null });
      setUploadFile(null);
      loadAll();
    } catch (err: any) {
      setIsUploading(false);
      showToast('error', err.message);
    }
  };

  const handleToggleGalleryActive = async (img: GalleryImage) => {
    try {
      const nextActive = img.is_active === 1 || img.is_active === true ? 0 : 1;
      await updateGalleryImage(img.id, {
        ...img,
        is_active: nextActive,
      });
      showToast('success', `Gallery image is now ${nextActive ? 'Active' : 'Disabled'}.`);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleDeleteGallery = (img: GalleryImage) => {
    setConfirmDelete({
      open: true,
      title: `Delete gallery image "${img.title}"?`,
      onConfirm: async () => {
        try {
          await deleteGalleryImage(img.id);
          showToast('success', 'Gallery image removed.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // ANNOUNCEMENTS OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementModal.item?.message?.trim()) {
      showToast('error', 'Announcement message is required.');
      return;
    }

    try {
      if (announcementModal.item.id) {
        await updateAdminAnnouncement(announcementModal.item.id, announcementModal.item);
        showToast('success', 'Announcement updated.');
      } else {
        await createAdminAnnouncement(announcementModal.item);
        showToast('success', 'Announcement added.');
      }
      setAnnouncementModal({ open: false, item: null });
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleToggleAnnouncementActive = async (ann: Announcement) => {
    try {
      const nextActive = ann.is_active === 1 || ann.is_active === true ? 0 : 1;
      await updateAdminAnnouncement(ann.id, {
        ...ann,
        is_active: nextActive,
      });
      showToast('success', `Announcement is now ${nextActive ? 'Active' : 'Disabled'}.`);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleDeleteAnnouncement = (ann: Announcement) => {
    setConfirmDelete({
      open: true,
      title: 'Delete Announcement?',
      description: `"${ann.message.slice(0, 60)}..." will be permanently removed.`,
      onConfirm: async () => {
        try {
          await deleteAdminAnnouncement(ann.id);
          showToast('success', 'Announcement removed.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // BRANDING OPERATIONS
  // ---------------------------------------------------------------------------
  const handleSaveBranding = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingBranding(true);
    try {
      let finalLogoUrl = brandingForm.logo_url;
      if (logoUploadFile) {
        setIsUploadingLogo(true);
        finalLogoUrl = await uploadAdminLogo(logoUploadFile);
        setIsUploadingLogo(false);
        setLogoUploadFile(null);
      }

      await updateAdminBranding({
        ...brandingForm,
        logo_url: finalLogoUrl,
      });

      showToast('success', 'Branding settings updated and applied across website.');
      loadAll();
    } catch (err: any) {
      setIsUploadingLogo(false);
      showToast('error', err.message || 'Failed to update branding settings.');
    } finally {
      setIsSavingBranding(false);
    }
  };

  const handleResetLogo = () => {
    setConfirmDelete({
      open: true,
      title: 'Reset Logo to Official Hindustan Petroleum Logo?',
      description: 'This will restore the standard HP corporate logo asset (/assets/hp-logo.png).',
      onConfirm: async () => {
        try {
          await deleteAdminLogo();
          setLogoUploadFile(null);
          showToast('success', 'Logo reset to official HP default.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // FEEDBACK & MODERATION OPERATIONS
  // ---------------------------------------------------------------------------
  const handleStatusChangeFeedback = async (id: number, status: 'PENDING' | 'APPROVED' | 'REJECTED') => {
    try {
      await updateFeedbackStatus(id, status);
      showToast('success', `Review status updated to ${status}.`);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleDeleteFeedback = (fb: FeedbackSubmission) => {
    setConfirmDelete({
      open: true,
      title: `Delete submission from "${fb.customer_name}"?`,
      onConfirm: async () => {
        try {
          await deleteFeedbackSubmission(fb.id);
          showToast('success', 'Feedback entry removed.');
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };

  // ---------------------------------------------------------------------------
  // BUSINESS & CUSTOMER SUPPORT ENQUIRY OPERATIONS
  // ---------------------------------------------------------------------------
  const handleStatusChangeEnquiry = async (
    id: number,
    status: 'New' | 'In Progress' | 'Responded' | 'Resolved'
  ) => {
    try {
      await updateEnquiryStatus(id, status);
      showToast('success', `Enquiry marked as ${status}.`);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  const handleOpenEnquiryDetail = (enq: CustomerEnquiry) => {
    setDetailModalEnquiry(enq);
    setDetailStatus(enq.status);
    setDetailNotes(enq.admin_notes || '');
  };

  const handleSaveEnquiryDetail = async () => {
    if (!detailModalEnquiry) return;
    setIsSavingEnquiryDetail(true);
    try {
      await updateEnquiryStatus(detailModalEnquiry.id, detailStatus, detailNotes);
      showToast('success', `Enquiry ${detailModalEnquiry.reference_no} updated.`);
      setDetailModalEnquiry(null);
      loadAll();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to update enquiry.');
    } finally {
      setIsSavingEnquiryDetail(false);
    }
  };

  const handleCopyRef = (refNo: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(refNo);
      setCopiedRefId(refNo);
      setTimeout(() => setCopiedRefId(null), 2000);
    }
  };

  const handleDeleteEnquiry = (enq: CustomerEnquiry) => {
    setConfirmDelete({
      open: true,
      title: `Delete enquiry ${enq.reference_no} from "${enq.customer_name}"?`,
      description: 'This enquiry record will be permanently removed.',
      onConfirm: async () => {
        try {
          await deleteEnquiry(enq.id);
          showToast('success', 'Enquiry deleted.');
          if (detailModalEnquiry?.id === enq.id) {
            setDetailModalEnquiry(null);
          }
          loadAll();
        } catch (err: any) {
          showToast('error', err.message);
        }
      },
    });
  };


  // ---------------------------------------------------------------------------
  // SETTINGS OPERATION
  // ---------------------------------------------------------------------------
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    try {
      await updateAdminSettings(settings);
      showToast('success', 'Station contact settings saved successfully.');
      loadAll();
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // ---------------------------------------------------------------------------
  // CHANGE PASSWORD
  // ---------------------------------------------------------------------------
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pwdCurrent || !pwdNew) {
      showToast('error', 'Please enter your current and new password.');
      return;
    }
    if (pwdNew !== pwdConfirm) {
      showToast('error', 'New password and confirmation do not match.');
      return;
    }
    if (pwdNew.length < 6) {
      showToast('error', 'New password must be at least 6 characters.');
      return;
    }

    try {
      await changeAdminPassword(pwdCurrent, pwdNew);
      showToast('success', 'Password updated successfully. Please use the new password next time.');
      setPwdCurrent('');
      setPwdNew('');
      setPwdConfirm('');
    } catch (err: any) {
      showToast('error', err.message);
    }
  };

  // Filter approved reviews for the dedicated Reviews tab
  const approvedReviews = feedback.filter((f) => f.status === 'APPROVED');

  return (
    <div className="min-h-screen bg-[#F3F6F9] text-[#263238] flex flex-col">
      {/* Toast Alert */}
      {toast && (
        <div
          className={`fixed bottom-5 right-5 z-50 p-4 rounded-xl shadow-lg border text-xs font-bold flex items-center gap-2 animate-in slide-in-from-bottom duration-200 ${
            toast.type === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
              : 'bg-rose-50 border-rose-300 text-rose-900'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Top Bar for Admin */}
      <header className="bg-[#123B68] text-white sticky top-0 z-40 shadow-sm border-b border-blue-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-11 bg-white p-1 rounded flex items-center justify-center">
                <img src="/assets/hp-logo.png" alt="HP Logo" className="w-full h-full object-contain" />
              </div>
              <div>
                <span className="text-base font-black tracking-tight text-white block">RAJ PETROLEUM</span>
                <span className="text-[10px] text-blue-200 font-semibold uppercase tracking-wider">
                  Management Console
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className="hidden sm:inline-flex items-center gap-1.5 text-xs text-blue-100 hover:text-white bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded transition-colors"
              >
                <span>View Live Site</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={loadAll}
                disabled={loading}
                title="Refresh All Data"
                className="p-1.5 text-blue-200 hover:text-white hover:bg-white/10 rounded transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              </button>

              <button
                onClick={handleLogout}
                className="inline-flex items-center gap-1.5 bg-[#D62828] hover:bg-[#b52020] text-white text-xs font-bold px-3 py-1.5 rounded transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>

        {/* Horizontal Navigation Menu for All Requested Management Sections */}
        <div className="bg-[#0756A5] border-t border-blue-800 overflow-x-auto scrollbar-none">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 py-1 whitespace-nowrap">
            {[
              { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'fuel', label: 'Fuel Prices', icon: Fuel },
              { id: 'about', label: 'About', icon: Info },
              { id: 'services', label: 'Customer Services', icon: Wrench },
              { id: 'gallery', label: 'Gallery', icon: Camera },
              { id: 'announcements', label: 'Announcement Bar', icon: Megaphone },
              { id: 'branding', label: 'Logo & Branding', icon: Palette },
              { id: 'appearance', label: 'Homepage Appearance', icon: ImageIcon },
              { id: 'feedback', label: 'Feedback', icon: MessageSquare },
              { id: 'reviews', label: 'Reviews', icon: Star },
              { id: 'enquiries', label: 'Customer Support', icon: Headphones },
              { id: 'settings', label: 'Contact Settings', icon: Settings },
              { id: 'password', label: 'Account Settings', icon: Key },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as AdminTab)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-white text-[#0756A5] shadow-xs'
                      : 'text-blue-100 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Management Overview</h1>
                <p className="text-xs text-slate-500 mt-0.5">Real-time business operations & support overview</p>
              </div>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Live System Connected</span>
              </span>
            </div>


            {/* Stats Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Fuel Categories</span>
                  <Fuel className="w-4 h-4 text-[#0756A5]" />
                </div>
                <div className="text-3xl font-black text-[#123B68] tabular-nums">{stats?.fuelCategories || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Active on public tariff</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Customer Services</span>
                  <Wrench className="w-4 h-4 text-[#0756A5]" />
                </div>
                <div className="text-3xl font-black text-[#123B68] tabular-nums">{stats?.customerServices || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Configured station amenities</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Gallery Photos</span>
                  <Camera className="w-4 h-4 text-[#0756A5]" />
                </div>
                <div className="text-3xl font-black text-[#123B68] tabular-nums">{stats?.galleryImages || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Station photographs</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Pending Feedback</span>
                  <MessageSquare className="w-4 h-4 text-amber-500" />
                </div>
                <div className="text-3xl font-black text-amber-600 tabular-nums">{stats?.pendingFeedback || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Awaiting moderation</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Approved Reviews</span>
                  <Star className="w-4 h-4 text-emerald-500" />
                </div>
                <div className="text-3xl font-black text-emerald-600 tabular-nums">{stats?.approvedReviews || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Published on website</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Pending Enquiries</span>
                  <Mail className="w-4 h-4 text-[#D62828]" />
                </div>
                <div className="text-3xl font-black text-[#D62828] tabular-nums">{stats?.pendingEnquiries || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Customer leads to call</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Resolved Enquiries</span>
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                </div>
                <div className="text-3xl font-black text-slate-700 tabular-nums">{stats?.resolvedEnquiries || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Successfully handled</span>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Enquiries</span>
                  <Mail className="w-4 h-4 text-blue-500" />
                </div>
                <div className="text-3xl font-black text-slate-900 tabular-nums">{stats?.totalEnquiries || 0}</div>
                <span className="text-[11px] text-slate-500 mt-1 block">Lifetime customer enquiries</span>
              </div>
            </div>

            {/* Quick Action Shortcuts */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
              <h3 className="text-sm font-bold text-[#123B68] uppercase tracking-wider mb-4">Quick Management Actions</h3>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <button
                  onClick={() => {
                    setActiveTab('fuel');
                    setFuelModal({
                      open: true,
                      item: {
                        name: '',
                        price_per_litre: 104.0,
                        effective_date: new Date().toISOString().split('T')[0],
                        is_active: 1,
                        display_order: fuelPrices.length + 1,
                      },
                    });
                  }}
                  className="p-3 bg-blue-50 hover:bg-blue-100/80 text-[#0756A5] rounded-lg text-xs font-bold text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>Update Fuel Price</span>
                  <Plus className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setActiveTab('appearance')}
                  className="p-3 bg-purple-50 hover:bg-purple-100/80 text-purple-900 rounded-lg text-xs font-bold text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>Manage Hero Background</span>
                  <ImageIcon className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setActiveTab('feedback')}
                  className="p-3 bg-amber-50 hover:bg-amber-100/80 text-amber-900 rounded-lg text-xs font-bold text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>Moderate Feedback ({stats?.pendingFeedback || 0})</span>
                  <MessageSquare className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setActiveTab('enquiries')}
                  className="p-3 bg-rose-50 hover:bg-rose-100/80 text-rose-900 rounded-lg text-xs font-bold text-left flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span>View Enquiries ({stats?.pendingEnquiries || 0})</span>
                  <Mail className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: FUEL PRICE MANAGEMENT */}
        {activeTab === 'fuel' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Fuel Price Management</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Update daily rates per litre, add fuel categories, or toggle active status. Saved values reflect immediately on the public website.
                </p>
              </div>
              <button
                onClick={() =>
                  setFuelModal({
                    open: true,
                    item: {
                      name: '',
                      price_per_litre: 104.0,
                      effective_date: new Date().toISOString().split('T')[0],
                      is_active: 1,
                      display_order: fuelPrices.length + 1,
                    },
                  })
                }
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Fuel Category</span>
              </button>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F3F6F9] border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="px-5 py-3.5">Category Name</th>
                      <th className="px-5 py-3.5">Price Per Litre</th>
                      <th className="px-5 py-3.5">Effective Date</th>
                      <th className="px-5 py-3.5">Status</th>
                      <th className="px-5 py-3.5">Display Order</th>
                      <th className="px-5 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {fuelPrices.map((fuel) => (
                      <tr key={fuel.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-5 py-3.5 font-bold text-slate-900">{fuel.name}</td>
                        <td className="px-5 py-3.5 font-extrabold text-[#0756A5] text-sm tabular-nums">
                          ₹{Number(fuel.price_per_litre).toFixed(2)}
                        </td>
                        <td className="px-5 py-3.5 text-slate-600">{fuel.effective_date}</td>
                        <td className="px-5 py-3.5">
                          {fuel.is_active ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                              <Check className="w-3 h-3" /> Active
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                              Inactive
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-slate-600 tabular-nums">{fuel.display_order}</td>
                        <td className="px-5 py-3.5 text-right space-x-2">
                          <button
                            onClick={() => setFuelModal({ open: true, item: { ...fuel } })}
                            className="p-1.5 text-slate-600 hover:text-[#0756A5] hover:bg-blue-50 rounded cursor-pointer"
                            title="Edit"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteFuel(fuel)}
                            className="p-1.5 text-slate-600 hover:text-[#D62828] hover:bg-rose-50 rounded cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ABOUT MANAGEMENT */}
        {activeTab === 'about' && (
          <div className="max-w-4xl space-y-6">
            <div>
              <h1 className="text-2xl font-black text-[#123B68]">About & Station Information</h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Manage business details, owner name, verified address, and description shown on the public site.
              </p>
            </div>

            {settings && (
              <form onSubmit={handleSaveSettings} className="bg-white p-6 sm:p-8 rounded-xl border border-slate-200 shadow-xs space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Business Name
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.business_name}
                      onChange={(e) => setSettings({ ...settings, business_name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Owner Name
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.owner_name}
                      onChange={(e) => setSettings({ ...settings, owner_name: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Verified Address
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={settings.address}
                    onChange={(e) => setSettings({ ...settings, address: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Plus Code
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.plus_code}
                      onChange={(e) => setSettings({ ...settings, plus_code: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Phone Number
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.phone}
                      onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={settings.email}
                      onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Operating Hours
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.opening_hours}
                    onChange={(e) => setSettings({ ...settings, opening_hours: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    About Section Description
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={settings.description}
                    onChange={(e) => setSettings({ ...settings, description: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  ></textarea>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    Save About Information
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* TAB 4: CUSTOMER SERVICES */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Customer Services & Facilities</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Configure station amenities displayed to motorists and commuters.
                </p>
              </div>
              <button
                onClick={() =>
                  setServiceModal({
                    open: true,
                    item: {
                      title: '',
                      description: '',
                      icon_name: 'Fuel',
                      is_active: 1,
                      display_order: services.length + 1,
                    },
                  })
                }
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Service</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {services.map((srv) => (
                <div key={srv.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0756A5] flex items-center justify-center overflow-hidden border border-blue-100">
                        {srv.icon_image_url ? (
                          <img
                            src={srv.icon_image_url}
                            alt={srv.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.currentTarget as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          <Wrench className="w-5 h-5 text-[#0756A5]" />
                        )}
                      </div>
                      <button
                        onClick={() => handleToggleServiceActive(srv)}
                        title="Click to toggle status"
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full cursor-pointer transition-colors ${
                          srv.is_active === 1 || srv.is_active === true
                            ? 'text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200'
                            : 'text-slate-600 bg-slate-100 hover:bg-slate-200 border border-slate-300'
                        }`}
                      >
                        {srv.is_active === 1 || srv.is_active === true ? '● Active (Public)' : '○ Disabled'}
                      </button>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{srv.title}</h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">{srv.description}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-400 font-medium">Order: {srv.display_order}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setServiceIconFile(null);
                          setServiceModal({ open: true, item: { ...srv } });
                        }}
                        className="p-1.5 text-slate-600 hover:text-[#0756A5] hover:bg-blue-50 rounded cursor-pointer"
                        title="Edit"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteService(srv)}
                        className="p-1.5 text-slate-600 hover:text-[#D62828] hover:bg-rose-50 rounded cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: GALLERY MANAGEMENT */}
        {activeTab === 'gallery' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Station Gallery Management</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Upload images from your device or provide image URLs. Updates appear on the public website immediately.
                </p>
              </div>
              <button
                onClick={() => {
                  setUploadFile(null);
                  setGalleryModal({
                    open: true,
                    item: {
                      title: '',
                      description: '',
                      image_url: '',
                      is_active: 1,
                      display_order: gallery.length + 1,
                    },
                  });
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Image</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {gallery.map((img) => (
                <div key={img.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="h-44 w-full bg-slate-100 overflow-hidden relative">
                      <img
                        src={img.image_url}
                        alt={img.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = '/assets/raj-petroleum-hero.jpg';
                        }}
                      />
                      <button
                        onClick={() => handleToggleGalleryActive(img)}
                        className={`absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs cursor-pointer transition-colors ${
                          img.is_active === 1 || img.is_active === true
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-700/80 text-white'
                        }`}
                      >
                        {img.is_active === 1 || img.is_active === true ? 'Active' : 'Disabled'}
                      </button>
                    </div>
                    <div className="p-4">
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">{img.title}</h4>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{img.description}</p>
                    </div>
                  </div>

                  <div className="p-4 pt-0 flex items-center justify-between border-t border-slate-100 mt-2">
                    <span className="text-[10px] text-slate-400 font-medium">Order: {img.display_order}</span>
                    <div className="flex items-center gap-1 pt-2">
                      <button
                        onClick={() => {
                          setUploadFile(null);
                          setGalleryModal({ open: true, item: { ...img } });
                        }}
                        className="p-1.5 text-slate-600 hover:text-[#0756A5] hover:bg-blue-50 rounded cursor-pointer"
                        title="Edit"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteGallery(img)}
                        className="p-1.5 text-slate-600 hover:text-[#D62828] hover:bg-rose-50 rounded cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5b: ANNOUNCEMENT BAR MANAGEMENT */}
        {activeTab === 'announcements' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Top Announcement Bar Management</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage the full-width notice bar displayed above the header. Active messages rotate automatically.
                </p>
              </div>
              <button
                onClick={() =>
                  setAnnouncementModal({
                    open: true,
                    item: {
                      message: '',
                      link_url: '',
                      is_active: 1,
                      display_order: announcements.length + 1,
                      start_date: '',
                      end_date: '',
                    },
                  })
                }
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg shadow-xs transition-colors self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Announcement</span>
              </button>
            </div>

            {/* Live Preview of top bar */}
            {announcements.filter((a) => a.is_active === 1 || a.is_active === true).length > 0 && (
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Live Public Banner Preview
                </span>
                <div className="bg-[#0756A5] text-[#FFFDF7] p-2.5 rounded-lg text-xs sm:text-sm font-medium flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Megaphone className="w-4 h-4 text-amber-300 shrink-0" />
                    <span>{announcements.filter((a) => a.is_active === 1 || a.is_active === true)[0]?.message}</span>
                  </div>
                  <span className="text-[11px] bg-[#054483] px-2 py-0.5 rounded text-amber-300">Live Preview</span>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {announcements.map((ann) => (
                <div
                  key={ann.id}
                  className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <button
                        onClick={() => handleToggleAnnouncementActive(ann)}
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full cursor-pointer transition-colors ${
                          ann.is_active === 1 || ann.is_active === true
                            ? 'text-emerald-800 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100'
                            : 'text-slate-600 bg-slate-100 border border-slate-300 hover:bg-slate-200'
                        }`}
                      >
                        {ann.is_active === 1 || ann.is_active === true ? '● Active' : '○ Disabled'}
                      </button>
                      <span className="text-[11px] text-slate-400 font-medium">Order: {ann.display_order}</span>
                      {(ann.start_date || ann.end_date) && (
                        <span className="text-[11px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                          Schedule: {ann.start_date || 'Anytime'} to {ann.end_date || 'Ongoing'}
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-bold text-slate-900">{ann.message}</p>
                    {ann.link_url && (
                      <p className="text-xs text-blue-600 mt-1 flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" />
                        <span>Link: {ann.link_url}</span>
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setAnnouncementModal({ open: true, item: { ...ann } })}
                      className="p-2 text-slate-600 hover:text-[#0756A5] hover:bg-blue-50 rounded-lg cursor-pointer"
                      title="Edit"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteAnnouncement(ann)}
                      className="p-2 text-slate-600 hover:text-[#D62828] hover:bg-rose-50 rounded-lg cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5c: LOGO & BRANDING MANAGEMENT */}
        {activeTab === 'branding' && (
          <div className="space-y-6 max-w-4xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Station Logo & Branding Management</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Update your retail outlet logo, brand name, and header tagline with live instant preview.
                </p>
              </div>

              <button
                type="button"
                onClick={handleResetLogo}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-[#D62828] border border-rose-200 text-xs font-bold rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset to Official HP Logo</span>
              </button>
            </div>

            {/* Live Header Simulation */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                Live Public Website Header Simulation
              </span>
              <div className="border border-slate-200 rounded-xl p-4 bg-white flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <img
                    src={logoUploadFile ? URL.createObjectURL(logoUploadFile) : brandingForm.logo_url}
                    alt="Brand Logo"
                    style={{ height: `${brandingForm.logo_height}px`, width: 'auto' }}
                    className="object-contain"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/assets/hp-logo.png';
                    }}
                  />
                  <div>
                    <span className="text-xl sm:text-2xl font-black tracking-tight text-[#0756A5] block">
                      {brandingForm.brand_name || 'RAJ PETROLEUM'}
                    </span>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                      {brandingForm.tagline || 'Hindustan Petroleum Retail Outlet'}
                    </span>
                  </div>
                </div>

                <div className="hidden sm:inline-flex items-center gap-2 bg-[#D62828] text-white text-xs font-extrabold uppercase tracking-wider px-3.5 py-2 rounded-lg">
                  Call Now
                </div>
              </div>
            </div>

            {/* Branding Form */}
            <form onSubmit={handleSaveBranding} className="bg-white p-6 sm:p-7 rounded-2xl border border-slate-200 shadow-xs space-y-5">
              <h3 className="text-sm font-black text-[#123B68] uppercase tracking-wider">Logo & Brand Identity Details</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Upload New Logo File
                  </label>
                  <input
                    type="file"
                    accept="image/png, image/jpeg, image/webp, image/svg+xml"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setLogoUploadFile(e.target.files[0]);
                      }
                    }}
                    className="w-full text-xs text-slate-600 file:mr-3 file:py-2 file:px-3.5 file:rounded file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-[#0756A5] hover:file:bg-blue-100 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Or Logo URL / Asset Path
                  </label>
                  <input
                    type="text"
                    value={brandingForm.logo_url}
                    onChange={(e) => setBrandingForm({ ...brandingForm, logo_url: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Logo Height in Header: <span className="text-[#0756A5] tabular-nums">{brandingForm.logo_height}px</span>
                  </label>
                </div>
                <input
                  type="range"
                  min="32"
                  max="80"
                  step="2"
                  value={brandingForm.logo_height}
                  onChange={(e) => setBrandingForm({ ...brandingForm, logo_height: parseInt(e.target.value, 10) || 56 })}
                  className="w-full accent-[#0756A5] cursor-pointer"
                />
                <span className="text-[11px] text-slate-400">Aspect ratio is strictly preserved without distortion.</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Business / Brand Name
                  </label>
                  <input
                    type="text"
                    required
                    value={brandingForm.brand_name}
                    onChange={(e) => setBrandingForm({ ...brandingForm, brand_name: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Header Subtitle / Tagline
                  </label>
                  <input
                    type="text"
                    required
                    value={brandingForm.tagline}
                    onChange={(e) => setBrandingForm({ ...brandingForm, tagline: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSavingBranding || isUploadingLogo}
                  className="px-6 py-2.5 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  {isSavingBranding || isUploadingLogo ? 'Saving Changes...' : 'Save Branding Settings'}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 6: HOMEPAGE APPEARANCE (NEW DEDICATED SECTION) */}
        {activeTab === 'appearance' && (
          <div className="space-y-6 max-w-5xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Homepage Appearance & Background</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Upload a new petrol pump photograph, adjust positioning, overlay contrast, and preview live changes before saving.
                </p>
              </div>

              <button
                type="button"
                onClick={handleDeleteBgImage}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-[#D62828] border border-rose-200 text-xs font-bold rounded-lg transition-colors cursor-pointer self-start sm:self-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Delete / Reset Background</span>
              </button>
            </div>

            <form onSubmit={handleSaveAppearance} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Controls Column */}
              <div className="lg:col-span-6 bg-white p-6 sm:p-7 rounded-2xl border border-slate-200 shadow-xs space-y-5">
                <h3 className="text-sm font-black text-[#123B68] uppercase tracking-wider flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-[#0756A5]" />
                  <span>Image Settings & Upload</span>
                </h3>

                {/* Option 1: File Upload */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Upload Background Photo from Device
                  </label>
                  <input
                    type="file"
                    accept="image/png, image/jpeg, image/webp"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        const file = e.target.files[0];
                        setBgUploadFile(file);
                        // Local preview URL
                        const localUrl = URL.createObjectURL(file);
                        setAppearanceForm({ ...appearanceForm, background_image: localUrl });
                      }
                    }}
                    className="w-full text-xs text-slate-600 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-[#0756A5] hover:file:bg-blue-100 cursor-pointer"
                  />
                  {bgUploadFile && (
                    <span className="text-[11px] font-semibold text-emerald-600 mt-1 block">
                      Selected file: {bgUploadFile.name} (Preview active below)
                    </span>
                  )}
                </div>

                <div className="text-center text-[11px] text-slate-400 font-bold uppercase">— OR USE IMAGE URL —</div>

                {/* Option 2: Image URL */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Background Image URL / Asset Path
                  </label>
                  <input
                    type="text"
                    value={appearanceForm.background_image || ''}
                    onChange={(e) => {
                      setBgUploadFile(null);
                      setAppearanceForm({ ...appearanceForm, background_image: e.target.value });
                    }}
                    placeholder="/assets/raj-petroleum-hero.jpg"
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>

                {/* Background Position */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Image Position
                    </label>
                    <select
                      value={appearanceForm.position}
                      onChange={(e) =>
                        setAppearanceForm({
                          ...appearanceForm,
                          position: e.target.value as 'center' | 'top' | 'bottom',
                        })
                      }
                      className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    >
                      <option value="center">Center (Default)</option>
                      <option value="top">Top Aligned</option>
                      <option value="bottom">Bottom Aligned</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Display Mode
                    </label>
                    <select
                      value={appearanceForm.display_mode}
                      onChange={(e) =>
                        setAppearanceForm({
                          ...appearanceForm,
                          display_mode: e.target.value as 'cover' | 'contain',
                        })
                      }
                      className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    >
                      <option value="cover">Cover (Fills entire hero)</option>
                      <option value="contain">Contain (Fit inside)</option>
                    </select>
                  </div>
                </div>

                {/* Overlay Intensity */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Blue Overlay Intensity
                    </label>
                    <span className="text-xs font-mono font-bold text-[#0756A5]">
                      {Math.round((appearanceForm.overlay_intensity || 0.45) * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="0.85"
                    step="0.05"
                    value={appearanceForm.overlay_intensity || 0.45}
                    onChange={(e) =>
                      setAppearanceForm({
                        ...appearanceForm,
                        overlay_intensity: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-[#0756A5] cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                    <span>10% (Bright / Transparent)</span>
                    <span>45% (Balanced)</span>
                    <span>85% (High Contrast)</span>
                  </div>
                </div>

                {/* Hero Section Height */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Desktop Hero Height
                  </label>
                  <select
                    value={appearanceForm.hero_height || 640}
                    onChange={(e) =>
                      setAppearanceForm({
                        ...appearanceForm,
                        hero_height: parseInt(e.target.value, 10),
                      })
                    }
                    className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  >
                    <option value={560}>560px — Compact</option>
                    <option value={620}>620px — Standard</option>
                    <option value={640}>640px — Recommended Premium</option>
                    <option value={680}>680px — Extra Spacious</option>
                    <option value={720}>720px — Full Showcase</option>
                  </select>
                </div>

                {/* Submit Action */}
                <div className="pt-3 flex items-center gap-3">
                  <button
                    type="submit"
                    disabled={isSavingAppearance || isUploadingBg}
                    className="flex-1 py-3 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-sm hover:shadow transition-all disabled:opacity-50 cursor-pointer text-center"
                  >
                    {isSavingAppearance || isUploadingBg ? 'Saving Changes...' : 'Save Appearance Changes'}
                  </button>
                </div>
              </div>

              {/* Live Preview Column */}
              <div className="lg:col-span-6 flex flex-col justify-between">
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-black text-[#123B68] uppercase tracking-wider flex items-center gap-1.5">
                        <Eye className="w-4 h-4 text-[#0756A5]" />
                        <span>Real-Time Hero Preview</span>
                      </span>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                        Live Simulation
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mb-4">
                      This shows exactly how the homepage hero will appear with your configured photograph, position, and overlay contrast.
                    </p>

                    {/* Preview Box */}
                    <div
                      className="relative w-full h-[320px] rounded-xl overflow-hidden flex flex-col items-center justify-center text-center p-4 shadow-inner border border-slate-300"
                      style={{
                        backgroundImage: `linear-gradient(to bottom, rgba(18, 59, 104, ${
                          appearanceForm.overlay_intensity || 0.45
                        }) 0%, rgba(7, 86, 165, ${Math.max(
                          0.15,
                          (appearanceForm.overlay_intensity || 0.45) - 0.1
                        )}) 45%, rgba(18, 59, 104, ${Math.min(
                          0.85,
                          (appearanceForm.overlay_intensity || 0.45) + 0.2
                        )}) 100%), url('${appearanceForm.background_image || '/assets/raj-petroleum-hero.jpg'}')`,
                        backgroundSize: appearanceForm.display_mode || 'cover',
                        backgroundPosition:
                          appearanceForm.position === 'top'
                            ? 'center top'
                            : appearanceForm.position === 'bottom'
                            ? 'center bottom'
                            : 'center center',
                        backgroundRepeat: 'no-repeat',
                        backgroundColor: '#123B68',
                      }}
                    >
                      <span className="text-[10px] font-bold text-white bg-white/20 backdrop-blur-xs px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-2 border border-white/30">
                        HP Authorized Retail Outlet
                      </span>

                      <h2 className="text-2xl font-black text-white uppercase tracking-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.7)]">
                        RAJ PETROLEUM
                      </h2>

                      <p className="text-[11px] text-slate-100 max-w-xs mt-1.5 leading-snug drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]">
                        Purity in Every Drop, Accuracy in Every Dispenser. Serving Nandre and Miraj Highway Commuters.
                      </p>

                      <div className="mt-3.5 flex items-center gap-2">
                        <span className="px-3 py-1 bg-[#D62828] text-white text-[10px] font-bold rounded shadow-xs">
                          Call Now
                        </span>
                        <span className="px-3 py-1 bg-white text-[#0756A5] text-[10px] font-bold rounded shadow-xs">
                          Get Directions
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex justify-between">
                    <span>Height: {appearanceForm.hero_height}px</span>
                    <span>Overlay: {Math.round((appearanceForm.overlay_intensity || 0.45) * 100)}%</span>
                    <span>Position: {appearanceForm.position}</span>
                  </div>
                </div>
              </div>
            </form>
          </div>
        )}

        {/* TAB 7: FEEDBACK (MODERATION OF ALL SUBMISSIONS) */}
        {activeTab === 'feedback' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Customer Feedback Moderation</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Review customer feedback submissions. Approving a submission publishes it to the Customer Reviews section on the public site.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F3F6F9] border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="px-5 py-3.5">Customer Name</th>
                      <th className="px-5 py-3.5">Rating</th>
                      <th className="px-5 py-3.5">Feedback Message</th>
                      <th className="px-5 py-3.5">Date</th>
                      <th className="px-5 py-3.5">Status</th>
                      <th className="px-5 py-3.5 text-right">Moderation Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {feedback.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/70">
                        <td className="px-5 py-3.5 font-bold text-slate-900 whitespace-nowrap">{item.customer_name}</td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`w-3.5 h-3.5 ${
                                  star <= item.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                                }`}
                              />
                            ))}
                          </div>
                        </td>
                        <td className="px-5 py-3.5 max-w-sm text-slate-700">{item.message}</td>
                        <td className="px-5 py-3.5 text-slate-500 whitespace-nowrap">
                          {new Date(item.submitted_at).toLocaleDateString()}
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          {item.status === 'APPROVED' && (
                            <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                              APPROVED (Published)
                            </span>
                          )}
                          {item.status === 'PENDING' && (
                            <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded">
                              PENDING
                            </span>
                          )}
                          {item.status === 'REJECTED' && (
                            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                              REJECTED
                            </span>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-right whitespace-nowrap space-x-1.5">
                          {item.status !== 'APPROVED' && (
                            <button
                              onClick={() => handleStatusChangeFeedback(item.id, 'APPROVED')}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold cursor-pointer"
                            >
                              Approve & Publish
                            </button>
                          )}
                          {item.status !== 'REJECTED' && (
                            <button
                              onClick={() => handleStatusChangeFeedback(item.id, 'REJECTED')}
                              className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[11px] font-bold cursor-pointer"
                            >
                              Reject
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteFeedback(item)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: REVIEWS (PUBLISHED APPROVED REVIEWS) */}
        {activeTab === 'reviews' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Published Customer Reviews</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  These verified reviews are currently displayed live in Section 7 of the public website.
                </p>
              </div>
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                {approvedReviews.length} Active Reviews
              </span>
            </div>

            {approvedReviews.length === 0 ? (
              <div className="bg-white p-8 rounded-xl border border-slate-200 text-center text-slate-500">
                <Star className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-700">No reviews published yet</h4>
                <p className="text-xs mt-1">Approve pending submissions from the Feedback tab to publish them here.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {approvedReviews.map((rev) => (
                  <div key={rev.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-3.5 h-3.5 ${
                                s <= rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {new Date(rev.submitted_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 italic leading-relaxed">"{rev.message}"</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900">{rev.customer_name}</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleStatusChangeFeedback(rev.id, 'PENDING')}
                          className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 text-[10px] font-bold rounded cursor-pointer"
                          title="Unpublish"
                        >
                          Unpublish
                        </button>
                        <button
                          onClick={() => handleDeleteFeedback(rev)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 9: BUSINESS & CUSTOMER SUPPORT ENQUIRIES */}
        {activeTab === 'enquiries' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-black text-[#123B68]">Business & Customer Support</h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage incoming customer assistance requests, commercial fleet inquiries, and bulk supply quotes.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-[#0756A5] bg-blue-50 border border-blue-200 px-3 py-1 rounded-full">
                  Total: {enquiries.length} Requests
                </span>
              </div>
            </div>

            {/* Search & Filter Toolbar */}
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Search by Reference No, Name, Mobile, Org, or Subject..."
                  value={enquirySearch}
                  onChange={(e) => setEnquirySearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-xs bg-[#F3F6F9] border border-slate-200 rounded-lg focus:outline-hidden focus:border-[#0756A5] focus:bg-white transition-colors"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Category Filter */}
                <div className="flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={enquiryCategoryFilter}
                    onChange={(e) => setEnquiryCategoryFilter(e.target.value)}
                    className="px-2.5 py-2 text-xs bg-[#F3F6F9] border border-slate-200 rounded-lg focus:outline-hidden focus:border-[#0756A5] font-semibold text-slate-700 cursor-pointer"
                  >
                    <option value="ALL">All Categories ({enquiries.length})</option>
                    <option value="General Enquiry">General Enquiry</option>
                    <option value="Customer Support">Customer Support</option>
                    <option value="Feedback or Complaint">Feedback or Complaint</option>
                    <option value="Business Enquiry">Business Enquiry</option>
                    <option value="Bulk Fuel Supply (Diesel / Petrol)">Bulk Fuel Supply</option>
                    <option value="Commercial & Fleet Accounts (HP DriveTrack Plus)">Fleet Accounts</option>
                    <option value="Agricultural Machinery Fueling">Agricultural Machinery</option>
                    <option value="Industrial Lubricants & Oils">Industrial Lubricants</option>
                    <option value="Dealership & Partnership Enquiry">Dealership & Partnership</option>
                    <option value="Billing & Invoice Queries">Billing & Invoices</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                {/* Status Filter */}
                <select
                  value={enquiryStatusFilter}
                  onChange={(e) => setEnquiryStatusFilter(e.target.value)}
                  className="px-2.5 py-2 text-xs bg-[#F3F6F9] border border-slate-200 rounded-lg focus:outline-hidden focus:border-[#0756A5] font-semibold text-slate-700 cursor-pointer"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="New">New</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Responded">Responded</option>
                  <option value="Resolved">Resolved</option>
                </select>

                {(enquirySearch || enquiryCategoryFilter !== 'ALL' || enquiryStatusFilter !== 'ALL') && (
                  <button
                    type="button"
                    onClick={() => {
                      setEnquirySearch('');
                      setEnquiryCategoryFilter('ALL');
                      setEnquiryStatusFilter('ALL');
                    }}
                    className="px-2.5 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>

            {/* Table of Enquiries */}
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F3F6F9] border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="px-5 py-3.5">Reference No</th>
                      <th className="px-5 py-3.5">Customer & Org</th>
                      <th className="px-5 py-3.5">Contact Number</th>
                      <th className="px-5 py-3.5">Category & Subject</th>
                      <th className="px-5 py-3.5">Status</th>
                      <th className="px-5 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(() => {
                      const filtered = enquiries.filter((enq) => {
                        const q = enquirySearch.toLowerCase().trim();
                        const matchesSearch =
                          q === '' ||
                          (enq.reference_no && enq.reference_no.toLowerCase().includes(q)) ||
                          (enq.customer_name && enq.customer_name.toLowerCase().includes(q)) ||
                          (enq.mobile_number && enq.mobile_number.includes(q)) ||
                          (enq.organization && enq.organization.toLowerCase().includes(q)) ||
                          (enq.subject && enq.subject.toLowerCase().includes(q)) ||
                          (enq.message && enq.message.toLowerCase().includes(q));

                        const matchesCategory =
                          enquiryCategoryFilter === 'ALL' || enq.category === enquiryCategoryFilter;

                        const matchesStatus =
                          enquiryStatusFilter === 'ALL' ||
                          enq.status === enquiryStatusFilter ||
                          (enquiryStatusFilter === 'New' && ((enq.status as string) === 'PENDING' || enq.status === 'New')) ||
                          (enquiryStatusFilter === 'In Progress' && ((enq.status as string) === 'IN_PROGRESS' || enq.status === 'In Progress')) ||
                          (enquiryStatusFilter === 'Resolved' && ((enq.status as string) === 'RESOLVED' || enq.status === 'Resolved')) ||
                          (enquiryStatusFilter === 'Responded' && enq.status === 'Responded');


                        return matchesSearch && matchesCategory && matchesStatus;
                      });

                      if (filtered.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="px-5 py-12 text-center text-slate-500">
                              <Headphones className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                              <p className="font-bold text-slate-700">No support requests found</p>
                              <p className="text-xs text-slate-400 mt-1">
                                {enquirySearch || enquiryCategoryFilter !== 'ALL' || enquiryStatusFilter !== 'ALL'
                                  ? 'Try adjusting your search keywords or filters.'
                                  : 'New customer support requests submitted via the public website will appear here.'}
                              </p>
                            </td>
                          </tr>
                        );
                      }

                      return filtered.map((enq) => {
                        const cleanDigits = enq.mobile_number.replace(/\D/g, '');
                        const callLink = cleanDigits.length === 10 ? `tel:+91${cleanDigits}` : `tel:${enq.mobile_number}`;
                        const waLink = `https://wa.me/91${cleanDigits.slice(-10)}`;
                        const isCopied = copiedRefId === enq.reference_no;

                        return (
                          <tr key={enq.id} className="hover:bg-slate-50/70 transition-colors">
                            {/* Ref No */}
                            <td className="px-5 py-3.5 whitespace-nowrap">
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono text-xs font-extrabold text-[#0756A5] bg-blue-50 border border-blue-200 px-2.5 py-1 rounded">
                                  {enq.reference_no || `RP-${enq.id}`}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleCopyRef(enq.reference_no || `RP-${enq.id}`)}
                                  className="p-1 text-slate-400 hover:text-[#0756A5] rounded cursor-pointer transition-colors"
                                  title="Copy Reference"
                                >
                                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              </div>
                              <span className="text-[10px] text-slate-400 block mt-1">
                                {new Date(enq.submitted_at).toLocaleDateString()} · {new Date(enq.submitted_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </td>

                            {/* Customer & Org */}
                            <td className="px-5 py-3.5">
                              <span className="font-bold text-slate-900 block">{enq.customer_name}</span>
                              {enq.organization ? (
                                <span className="inline-flex items-center gap-1 text-[11px] text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded font-medium mt-0.5">
                                  <Building2 className="w-3 h-3" />
                                  <span>{enq.organization}</span>
                                </span>
                              ) : null}
                            </td>

                            {/* Contact Details */}
                            <td className="px-5 py-3.5 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <a
                                  href={callLink}
                                  className="font-bold text-[#0756A5] hover:underline tabular-nums"
                                >
                                  {enq.mobile_number}
                                </a>
                                <a
                                  href={waLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                                  title="Chat on WhatsApp"
                                >
                                  <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
                                    <path d="M12.031 2C6.495 2 2 6.495 2 12.031c0 1.77.464 3.498 1.346 5.027L2 22l5.086-1.332A10.02 10.02 0 0 0 12.031 22C17.567 22 22 17.505 22 12.031 22 6.495 17.567 2 12.031 2zm5.88 14.188c-.244.686-1.42 1.31-1.956 1.39-.516.077-1.19.11-3.414-.81-2.846-1.176-4.68-4.07-4.821-4.258-.141-.188-1.157-1.54-1.157-2.939 0-1.398.73-2.086.99-2.368.259-.283.567-.354.755-.354.189 0 .378.002.544.01.176.009.412-.067.644.49.244.588.828 2.02.9 2.167.072.148.12.321.023.515-.096.195-.145.316-.288.487-.144.17-.303.38-.432.51-.144.143-.294.298-.127.585.167.287.742 1.226 1.593 1.984 1.096.977 2.02 1.28 2.308 1.424.288.143.456.12.624-.073.168-.194.721-.839.914-1.127.192-.288.384-.24.647-.144.263.097 1.666.786 1.952.93.287.144.478.216.548.337.07.12.07.7-.174 1.386z" />
                                  </svg>
                                </a>
                              </div>
                              {enq.email ? (
                                <span className="text-[11px] text-slate-500 block">{enq.email}</span>
                              ) : null}
                            </td>

                            {/* Category & Subject */}
                            <td className="px-5 py-3.5 max-w-xs">
                              <span className="text-[10px] font-bold text-[#0756A5] bg-blue-50 px-2 py-0.5 rounded uppercase tracking-wider block w-fit mb-1">
                                {enq.category || 'General Enquiry'}
                              </span>
                              <span className="font-bold text-slate-800 line-clamp-1">{enq.subject}</span>
                              <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{enq.message}</p>
                            </td>

                            {/* Status */}
                            <td className="px-5 py-3.5 whitespace-nowrap">
                              <select
                                value={
                                  (enq.status as string) === 'PENDING'
                                    ? 'New'
                                    : (enq.status as string) === 'IN_PROGRESS'
                                    ? 'In Progress'
                                    : (enq.status as string) === 'RESOLVED'
                                    ? 'Resolved'
                                    : enq.status
                                }
                                onChange={(e) =>
                                  handleStatusChangeEnquiry(
                                    enq.id,
                                    e.target.value as 'New' | 'In Progress' | 'Responded' | 'Resolved'
                                  )
                                }
                                className={`px-2.5 py-1 text-[11px] font-bold rounded-md border cursor-pointer ${
                                  enq.status === 'New' || (enq.status as string) === 'PENDING'
                                    ? 'bg-amber-50 text-amber-800 border-amber-300'
                                    : enq.status === 'In Progress' || (enq.status as string) === 'IN_PROGRESS'
                                    ? 'bg-sky-50 text-sky-800 border-sky-300'
                                    : enq.status === 'Responded'
                                    ? 'bg-purple-50 text-purple-800 border-purple-300'
                                    : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                }`}
                              >

                                <option value="New">New</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Responded">Responded</option>
                                <option value="Resolved">Resolved</option>
                              </select>
                            </td>

                            {/* Actions */}
                            <td className="px-5 py-3.5 text-right whitespace-nowrap space-x-2">
                              <button
                                onClick={() => handleOpenEnquiryDetail(enq)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-[#0756A5] hover:bg-[#123B68] text-white text-[11px] font-bold rounded-md cursor-pointer transition-colors shadow-2xs"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Details</span>
                              </button>
                              <button
                                onClick={() => handleDeleteEnquiry(enq)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 rounded cursor-pointer transition-colors"
                                title="Delete Enquiry"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      });
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 10: SETTINGS & CONTACT */}
        {activeTab === 'settings' && (
          <div className="max-w-3xl space-y-6">
            <div>
              <h1 className="text-2xl font-black text-[#123B68]">Station Contact & Address Settings</h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Update verified telephone helpline, WhatsApp number, email, and plus code coordinates.
              </p>
            </div>

            {settings && (
              <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Call Number (Direct Helpline)
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.phone}
                      onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">Configured: 93721 47039</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      WhatsApp Number (Direct Chat)
                    </label>
                    <input
                      type="text"
                      required
                      value={settings.whatsapp || '8766660414'}
                      onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                    />
                    <span className="text-[11px] text-slate-400 mt-1 block">Configured: 8766660414</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Station Email
                  </label>
                  <input
                    type="email"
                    required
                    value={settings.email}
                    onChange={(e) => setSettings({ ...settings, email: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Google Maps Plus Code
                  </label>
                  <input
                    type="text"
                    required
                    value={settings.plus_code}
                    onChange={(e) => setSettings({ ...settings, plus_code: e.target.value })}
                    className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">Configured: WGXW+GXR</span>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    Update Contact Settings
                  </button>
                </div>
              </form>
            )}
          </div>
        )}


        {/* TAB 11: ACCOUNT SECURITY */}
        {activeTab === 'password' && (
          <div className="max-w-xl space-y-6">
            <div>
              <h1 className="text-2xl font-black text-[#123B68]">Administrator Account Security</h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Change your password securely. Credentials are encrypted and protected.
              </p>
            </div>

            <form onSubmit={handleChangePassword} className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={pwdCurrent}
                  onChange={(e) => setPwdCurrent(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  New Password (min 6 characters)
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={pwdNew}
                  onChange={(e) => setPwdNew(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={pwdConfirm}
                  onChange={(e) => setPwdConfirm(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-[#0756A5]"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold uppercase tracking-wider rounded-lg shadow-xs transition-colors cursor-pointer"
                >
                  Update Administrator Password
                </button>
              </div>
            </form>
          </div>
        )}
      </main>

      {/* MODAL: FUEL CATEGORY */}
      {fuelModal.open && fuelModal.item && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl animate-in zoom-in-95 duration-150">
            <h3 className="text-lg font-black text-[#123B68] mb-4">
              {fuelModal.item.id ? 'Edit Fuel Category' : 'Add New Fuel Category'}
            </h3>
            <form onSubmit={handleSaveFuel} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Category Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CNG, Premium Diesel"
                  value={fuelModal.item.name || ''}
                  onChange={(e) =>
                    setFuelModal({
                      ...fuelModal,
                      item: { ...fuelModal.item, name: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Price Per Litre (₹)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={fuelModal.item.price_per_litre || ''}
                  onChange={(e) =>
                    setFuelModal({
                      ...fuelModal,
                      item: { ...fuelModal.item, price_per_litre: parseFloat(e.target.value) || 0 },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Effective Date
                </label>
                <input
                  type="date"
                  required
                  value={fuelModal.item.effective_date || ''}
                  onChange={(e) =>
                    setFuelModal({
                      ...fuelModal,
                      item: { ...fuelModal.item, effective_date: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={fuelModal.item.display_order || 0}
                    onChange={(e) =>
                      setFuelModal({
                        ...fuelModal,
                        item: { ...fuelModal.item, display_order: parseInt(e.target.value, 10) || 0 },
                      })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Status
                  </label>
                  <select
                    value={fuelModal.item.is_active ? 1 : 0}
                    onChange={(e) =>
                      setFuelModal({
                        ...fuelModal,
                        item: { ...fuelModal.item, is_active: parseInt(e.target.value, 10) },
                      })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                  >
                    <option value={1}>Active</option>
                    <option value={0}>Inactive</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setFuelModal({ open: false, item: null })}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CUSTOMER SERVICE */}
      {serviceModal.open && serviceModal.item && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl animate-in zoom-in-95 duration-150">
            <h3 className="text-lg font-black text-[#123B68] mb-4">
              {serviceModal.item.id ? 'Edit Service' : 'Add New Service'}
            </h3>
            <form onSubmit={handleSaveService} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Service Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Nitrogen Air Station"
                  value={serviceModal.item.title || ''}
                  onChange={(e) =>
                    setServiceModal({
                      ...serviceModal,
                      item: { ...serviceModal.item, title: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Details about this service..."
                  value={serviceModal.item.description || ''}
                  onChange={(e) =>
                    setServiceModal({
                      ...serviceModal,
                      item: { ...serviceModal.item, description: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Icon Name
                  </label>
                  <select
                    value={serviceModal.item.icon_name || 'Fuel'}
                    onChange={(e) =>
                      setServiceModal({
                        ...serviceModal,
                        item: { ...serviceModal.item, icon_name: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                  >
                    <option value="Fuel">Fuel (Dispenser)</option>
                    <option value="Zap">Zap (Power Petrol)</option>
                    <option value="Gauge">Gauge (Air/Nitrogen)</option>
                    <option value="Droplets">Droplets (Lubricants)</option>
                    <option value="Sparkles">Sparkles (Restroom)</option>
                    <option value="GlassWater">GlassWater (Drinking Water)</option>
                    <option value="CreditCard">CreditCard (Digital Pay)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={serviceModal.item.display_order || 0}
                    onChange={(e) =>
                      setServiceModal({
                        ...serviceModal,
                        item: { ...serviceModal.item, display_order: parseInt(e.target.value, 10) || 0 },
                      })
                    }
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setServiceModal({ open: false, item: null })}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: GALLERY IMAGE */}
      {galleryModal.open && galleryModal.item && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl animate-in zoom-in-95 duration-150">
            <h3 className="text-lg font-black text-[#123B68] mb-4">
              {galleryModal.item.id ? 'Edit Gallery Photograph' : 'Add Gallery Photograph'}
            </h3>
            <form onSubmit={handleSaveGallery} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Upload Image from Device
                </label>
                <input
                  type="file"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setUploadFile(e.target.files[0]);
                    }
                  }}
                  className="w-full text-xs text-slate-600 file:mr-3 file:py-1.5 file:px-3 file:rounded file:border-0 file:text-xs file:font-bold file:bg-blue-50 file:text-[#0756A5] hover:file:bg-blue-100 cursor-pointer"
                />
              </div>

              <div className="text-center text-[11px] text-slate-400 font-bold uppercase">— OR USE IMAGE URL —</div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Image URL / Asset Path
                </label>
                <input
                  type="text"
                  placeholder="/assets/raj-petroleum-hero.jpg"
                  value={galleryModal.item.image_url || ''}
                  onChange={(e) =>
                    setGalleryModal({
                      ...galleryModal,
                      item: { ...galleryModal.item, image_url: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Pump Forecourt at Dusk"
                  value={galleryModal.item.title || ''}
                  onChange={(e) =>
                    setGalleryModal({
                      ...galleryModal,
                      item: { ...galleryModal.item, title: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Short caption describing the view..."
                  value={galleryModal.item.description || ''}
                  onChange={(e) =>
                    setGalleryModal({
                      ...galleryModal,
                      item: { ...galleryModal.item, description: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                ></textarea>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setGalleryModal({ open: false, item: null })}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="px-5 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg cursor-pointer"
                >
                  {isUploading ? 'Uploading...' : 'Save Photograph'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ENQUIRY DETAILS & RESPONSE MODAL */}
      {detailModalEnquiry && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl animate-in zoom-in-95 duration-150 my-8 border border-slate-200">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-200 gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs font-black text-[#0756A5] bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded">
                    {detailModalEnquiry.reference_no || `RP-${detailModalEnquiry.id}`}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyRef(detailModalEnquiry.reference_no || `RP-${detailModalEnquiry.id}`)}
                    className="p-1 text-slate-400 hover:text-[#0756A5] rounded cursor-pointer transition-colors"
                    title="Copy Reference"
                  >
                    {copiedRefId === (detailModalEnquiry.reference_no || `RP-${detailModalEnquiry.id}`) ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <span className="text-[11px] text-slate-400">
                    Received {new Date(detailModalEnquiry.submitted_at).toLocaleDateString()} at{' '}
                    {new Date(detailModalEnquiry.submitted_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <h3 className="text-xl font-black text-[#123B68]">Support Request Details</h3>
              </div>

              <button
                type="button"
                onClick={() => setDetailModalEnquiry(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Content Body */}
            <div className="py-4 space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              {/* Customer Info Card */}
              <div className="bg-[#F3F6F9] p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Customer Name
                  </span>
                  <span className="text-sm font-bold text-slate-900 block mt-0.5">
                    {detailModalEnquiry.customer_name}
                  </span>
                  {detailModalEnquiry.organization && (
                    <span className="inline-flex items-center gap-1 text-xs text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded font-medium mt-1">
                      <Building2 className="w-3 h-3" />
                      <span>{detailModalEnquiry.organization}</span>
                    </span>
                  )}
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Contact Phone
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-sm font-extrabold text-[#0756A5] tabular-nums">
                      {detailModalEnquiry.mobile_number}
                    </span>
                    {/* Quick Call Button */}
                    <a
                      href={
                        detailModalEnquiry.mobile_number.replace(/\D/g, '').length === 10
                          ? `tel:+91${detailModalEnquiry.mobile_number.replace(/\D/g, '')}`
                          : `tel:${detailModalEnquiry.mobile_number}`
                      }
                      className="px-2 py-1 bg-[#D62828] text-white text-[10px] font-bold rounded shadow-2xs hover:bg-[#b81d1d] transition-colors"
                      title="Call customer"
                    >
                      Call
                    </a>
                    {/* Quick WhatsApp Button */}
                    <a
                      href={`https://wa.me/91${detailModalEnquiry.mobile_number.replace(/\D/g, '').slice(-10)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2 py-1 bg-[#25D366] text-white text-[10px] font-bold rounded shadow-2xs hover:bg-[#20ba59] transition-colors"
                      title="Chat on WhatsApp"
                    >
                      WhatsApp
                    </a>
                  </div>
                  {detailModalEnquiry.email && (
                    <span className="text-xs text-slate-600 block mt-1">
                      Email: <a href={`mailto:${detailModalEnquiry.email}`} className="text-[#0756A5] underline">{detailModalEnquiry.email}</a>
                    </span>
                  )}
                </div>
              </div>

              {/* Category & Subject */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    Category:
                  </span>
                  <span className="text-xs font-bold text-[#0756A5] bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded">
                    {detailModalEnquiry.category || 'General Enquiry'}
                  </span>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mt-2">
                    Subject:
                  </span>
                  <span className="text-sm font-extrabold text-slate-900 block">
                    {detailModalEnquiry.subject}
                  </span>
                </div>
              </div>

              {/* Full Message */}
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Customer Message:
                </span>
                <div className="p-4 bg-[#FFFDF7] border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-wrap">
                  {detailModalEnquiry.message}
                </div>
              </div>

              {/* Status Update & Internal Notes */}
              <div className="pt-2 border-t border-slate-200 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Request Status
                    </label>
                    <select
                      value={detailStatus}
                      onChange={(e) => setDetailStatus(e.target.value as CustomerEnquiry['status'])}
                      className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-300 rounded-lg focus:border-[#0756A5] cursor-pointer"
                    >
                      <option value="New">New (Needs Attention)</option>
                      <option value="In Progress">In Progress (Follow-up under way)</option>
                      <option value="Responded">Responded (Customer contacted)</option>
                      <option value="Resolved">Resolved (Completed)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Quick Status Tag
                    </label>
                    <div className="flex items-center gap-1.5 pt-1">
                      {(['New', 'In Progress', 'Responded', 'Resolved'] as const).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setDetailStatus(st)}
                          className={`px-2 py-1 text-[10px] font-bold rounded cursor-pointer transition-colors ${
                            detailStatus === st
                              ? 'bg-[#0756A5] text-white shadow-2xs'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Internal Management Notes
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Add follow-up notes, quote details, attendant callbacks, or resolution remarks..."
                    value={detailNotes}
                    onChange={(e) => setDetailNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:border-[#0756A5] focus:outline-hidden"
                  ></textarea>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  handleDeleteEnquiry(detailModalEnquiry);
                }}
                className="px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors inline-flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Enquiry</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDetailModalEnquiry(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleSaveEnquiryDetail}
                  disabled={isSavingEnquiryDetail}
                  className="px-5 py-2 bg-[#0756A5] hover:bg-[#123B68] text-white text-xs font-bold rounded-lg cursor-pointer shadow-sm transition-all disabled:opacity-50"
                >
                  {isSavingEnquiryDetail ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}

      {confirmDelete.open && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-sm w-full p-6 shadow-xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-[#D62828] mb-3">
              <Trash2 className="w-5 h-5" />
              <h4 className="text-base font-bold text-slate-900">Confirm Deletion</h4>
            </div>
            <p className="text-xs text-slate-700 font-semibold mb-2">{confirmDelete.title}</p>
            {confirmDelete.description && (
              <p className="text-xs text-slate-500 leading-relaxed mb-4">{confirmDelete.description}</p>
            )}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setConfirmDelete({ open: false, title: '', onConfirm: async () => {} })}
                className="px-3.5 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  const action = confirmDelete.onConfirm;
                  setConfirmDelete({ open: false, title: '', onConfirm: async () => {} });
                  await action();
                }}
                className="px-4 py-1.5 text-xs font-bold bg-[#D62828] hover:bg-[#b52020] text-white rounded-lg cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
