# Raj Petroleum — Official Business Website & Dealer Management System

A production-grade, full-stack web application designed for **Raj Petroleum**, an authorized Hindustan Petroleum (HPCL) retail outlet situated in Nandre, Taluka Miraj, District Sangli, Maharashtra.

---

## 1. Verified Business Information

- **Business Name**: Raj Petroleum
- **Dealer / Owner**: Sunita Patil
- **Authorization**: Hindustan Petroleum Corporation Limited (HPCL) Retail Outlet
- **Address**: Shop No. 1, Main Road, Nandre, Taluka Miraj, District Sangli, Maharashtra 416416, India
- **Google Maps Plus Code**: `WGXW+GXR`
- **Operating Hours**: Open 24 Hours / 7 Days a Week

---

## 2. Technology Stack

### Frontend
- **Framework**: React 19 + TypeScript
- **Styling**: Tailwind CSS v4 with custom brand color palette
  - Primary Petrol Blue: `#0756A5`
  - Deep Blue: `#123B68`
  - Soft Cream: `#FFFDF7`
  - Light Grey: `#F3F6F9`
  - Text Charcoal: `#263238`
  - Red Accent: `#D62828`
- **Icons**: Lucide React
- **Routing**: React Router (`/`, `/admin/login`, `/admin/dashboard`)

### Backend
- **Runtime**: Node.js + Express.js
- **Architecture**: Modular REST API with centralized error handling
- **Security**:
  - Cryptographic password hashing with `bcrypt` (10 rounds)
  - Signed JSON Web Tokens (`jsonwebtoken`) with 24-hour expiration
  - In-memory IP rate limiter protecting login endpoints
  - Server-side data sanitization and strict validation
- **File Uploads**: `multer` handling secure multipart image uploads with MIME-type filtering to `/public/uploads/`

### Database
- **Relational Architecture**:
  - `administrators`
  - `business_settings`
  - `fuel_categories` (Live fuel pricing per litre and effective date)
  - `customer_services`
  - `gallery_images`
  - `feedback_submissions` (Moderated reviews workflow)
  - `enquiries` (Private customer contact requests)
  - `audit_logs`
- **Engine**: Production-ready MySQL schema (`schema.sql`) and embedded zero-configuration persistent SQLite relational database powered by `sql.js` (saves to `/data/raj_petroleum.sqlite`).

---

## 3. Exact Public Section Order

1. **Homepage Hero**: Features the real Raj Petroleum forecourt photograph, central title, certified HP dealership badge, and functional "Call Now" / "Get Directions" buttons.
2. **Live Fuel Price**: Displays daily tariff (Petrol, Diesel, HP Power Petrol) with last updated timestamp and fallback message when unentered.
3. **About Raj Petroleum**: Details owner Sunita Patil, authorized HP credentials, and business values.
4. **Customer Services**: Displays verified amenities (high-speed dispensers, power petrol, nitrogen air station, genuine lubricants, clean restrooms, drinking water, and digital payments).
5. **Station Gallery**: Responsive grid with interactive modal preview, titles, and descriptions.
6. **Customer Feedback Form**: Interactive 1–5 star rating and review submission for moderation.
7. **Customer Reviews**: Displays only approved, verified customer testimonials.
8. **Customer Enquiry Form**: Direct inquiries for bulk fuel supply, fleet arrangements, and questions.
9. **Find Raj Petroleum**: Embedded Google Maps view with Plus Code `WGXW+GXR` and instant driving directions.
10. **Contact Information**: Verified telephone helpline, email, station timings, and proprietor details.
11. **Footer**: Quick navigation links, contact summary, and secure dealer administration access.

---

## 4. Initial Setup & Installation

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Environment Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure `JWT_SECRET` has a strong secret phrase.

### Step 3: MySQL Configuration (Optional Production Deployment)
To run against a dedicated MySQL server:
```bash
mysql -u root -p < schema.sql
```
Update `DATABASE_URL` in `.env` with your MySQL connection string.

---

## 5. Development & Production Commands

### Start Development Server
```bash
npm run dev
```
The server starts Express and Vite on `http://localhost:3000`.

### Build for Production
```bash
npm run build
```

### Start Production Server
```bash
npm start
```

---

## 6. Secure Administrator Portal

- **Login URL**: `/admin/login`
- **Dashboard URL**: `/admin/dashboard`
- **Security Standards**:
  - Input fields start empty.
  - No prefilling or plaintext credentials in source code.
  - Incorrect attempts yield: *"Invalid username or password."*
  - Protected API routes require `Authorization: Bearer <token>`.
  - Admin can update fuel categories, customer services, gallery images, moderate reviews, manage inquiries, and change the administrator password.
