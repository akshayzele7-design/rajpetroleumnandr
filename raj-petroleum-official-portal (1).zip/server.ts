import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import dotenv from 'dotenv';
import { initDatabase, queryAll, queryOne, execute } from './server/db.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || 'raj_petroleum_secure_jwt_secret_token_2026';
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProd = process.env.NODE_ENV === 'production';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Uploads directory supporting persistent mount path
const UPLOADS_DIR = process.env.UPLOADS_DIR
  ? path.resolve(process.env.UPLOADS_DIR)
  : path.resolve(__dirname, 'public', 'uploads');

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Serve public static assets
app.use('/assets', express.static(path.resolve(__dirname, 'public', 'assets')));
app.use('/uploads', express.static(UPLOADS_DIR));

// Configure multer for persistent gallery uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const cleanName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
    const uniqueSuffix = `${Date.now()}_${Math.round(Math.random() * 1e6)}`;
    cb(null, `${cleanName}_${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|gif/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    const mime = file.mimetype;
    if (allowed.test(ext) && (mime.startsWith('image/') || allowed.test(mime))) {
      cb(null, true);
    } else {
      cb(new Error('Only JPEG, PNG, WEBP, and GIF images are allowed.'));
    }
  },
});

// Simple in-memory login rate limiter
const loginAttempts = new Map<string, { count: number; lastAttempt: number }>();
function checkLoginRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry) {
    loginAttempts.set(ip, { count: 1, lastAttempt: now });
    return true;
  }
  // Reset window after 5 minutes
  if (now - entry.lastAttempt > 5 * 60 * 1000) {
    loginAttempts.set(ip, { count: 1, lastAttempt: now });
    return true;
  }
  entry.count++;
  entry.lastAttempt = now;
  return entry.count <= 10;
}

// JWT Authentication Middleware for Protected Routes
export interface AuthenticatedRequest extends Request {
  adminUser?: { id: number; username: string };
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized. Authentication token required.' });
    return;
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number; username: string };
    req.adminUser = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid or expired session. Please log in again.' });
  }
}

// ---------------------------------------------------------------------------
// HEALTH CHECK ENDPOINTS
// ---------------------------------------------------------------------------
app.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'healthy',
    service: 'Raj Petroleum Full-Stack API',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'healthy',
    service: 'Raj Petroleum Full-Stack API',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// ---------------------------------------------------------------------------
// PUBLIC API ROUTES
// ---------------------------------------------------------------------------

// 1. Business Settings
app.get('/api/public/settings', (_req: Request, res: Response) => {
  try {
    const settings = queryOne(
      'SELECT business_name, owner_name, address, plus_code, phone, whatsapp, email, opening_hours, description FROM business_settings LIMIT 1'
    );
    res.json(settings || {});
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch business settings', details: err.message });
  }
});


// 1.1 Homepage Appearance Settings
app.get('/api/public/appearance', (_req: Request, res: Response) => {
  try {
    const appearance = queryOne(
      'SELECT background_image, position, display_mode, overlay_intensity, hero_height, updated_at FROM homepage_appearance LIMIT 1'
    );
    res.json(appearance || {
      background_image: '/assets/raj-petroleum-hero.jpg',
      position: 'center',
      display_mode: 'cover',
      overlay_intensity: 0.45,
      hero_height: 640,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch homepage appearance', details: err.message });
  }
});

// 2. Live Fuel Prices
app.get('/api/public/fuel-prices', (_req: Request, res: Response) => {
  try {
    const prices = queryAll(
      'SELECT id, name, price_per_litre, effective_date, is_active, updated_at FROM fuel_categories WHERE is_active = 1 ORDER BY display_order ASC, id ASC'
    );
    res.json(prices);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch fuel prices', details: err.message });
  }
});

// 3. Customer Services
app.get('/api/public/services', (_req: Request, res: Response) => {
  try {
    const services = queryAll(
      'SELECT id, title, description, icon_name, icon_image_url, is_active, display_order FROM customer_services WHERE is_active = 1 ORDER BY display_order ASC, id ASC'
    );
    res.json(services);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch customer services', details: err.message });
  }
});

// 4. Gallery Images
app.get('/api/public/gallery', (_req: Request, res: Response) => {
  try {
    const images = queryAll(
      'SELECT id, title, description, image_url, is_active, display_order FROM gallery_images WHERE is_active = 1 ORDER BY display_order ASC, id DESC'
    );
    res.json(images);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch gallery images', details: err.message });
  }
});

// 4b. Active Announcements
app.get('/api/public/announcements', (_req: Request, res: Response) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const announcements = queryAll(
      `SELECT id, message, link_url, is_active, display_order, start_date, end_date 
       FROM announcements 
       WHERE is_active = 1 
         AND (start_date IS NULL OR start_date = '' OR start_date <= ?)
         AND (end_date IS NULL OR end_date = '' OR end_date >= ?)
       ORDER BY display_order ASC, id DESC`,
      [today, today]
    );
    res.json(announcements);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch announcements', details: err.message });
  }
});

// 4c. Branding & Logo Settings
app.get('/api/public/branding', (_req: Request, res: Response) => {
  try {
    const branding = queryOne(
      'SELECT id, logo_url, logo_height, brand_name, tagline, updated_at FROM branding_settings LIMIT 1'
    ) || {
      logo_url: '/assets/hp-logo.png',
      logo_height: 56,
      brand_name: 'RAJ PETROLEUM',
      tagline: 'Hindustan Petroleum Retail Outlet',
    };
    res.json(branding);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch branding settings', details: err.message });
  }
});

// 4d. Public HP Pay App Configuration
app.get('/api/public/hp-pay', (_req: Request, res: Response) => {
  try {
    const row = queryOne<any>(
      'SELECT id, title, heading, description, app_icon_url, play_store_url, learn_more_url, is_visible, is_deleted, display_order, features_json, updated_at FROM hp_pay_section WHERE is_deleted = 0 AND is_visible = 1 LIMIT 1'
    );
    if (!row) {
      res.json(null);
      return;
    }
    let features = [];
    try {
      features = JSON.parse(row.features_json || '[]');
    } catch {
      features = [];
    }
    res.json({
      ...row,
      features,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch HP Pay configuration', details: err.message });
  }
});

// 5. Approved Customer Reviews Only
app.get('/api/public/reviews', (_req: Request, res: Response) => {
  try {
    const reviews = queryAll(
      "SELECT id, customer_name, rating, message, submitted_at FROM feedback_submissions WHERE status = 'APPROVED' ORDER BY id DESC"
    );
    res.json(reviews);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch customer reviews', details: err.message });
  }
});

// 6. Submit Customer Feedback
app.post('/api/public/feedback', (req: Request, res: Response) => {
  try {
    const { customer_name, rating, message } = req.body;

    if (!customer_name || typeof customer_name !== 'string' || !customer_name.trim()) {
      res.status(400).json({ error: 'Please enter your name.' });
      return;
    }
    const numRating = Number(rating);
    if (isNaN(numRating) || numRating < 1 || numRating > 5) {
      res.status(400).json({ error: 'Rating must be between 1 and 5 stars.' });
      return;
    }
    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Please enter your feedback message.' });
      return;
    }

    const cleanName = customer_name.trim().slice(0, 150);
    const cleanMsg = message.trim().slice(0, 2000);
    const now = new Date().toISOString();

    execute(
      'INSERT INTO feedback_submissions (customer_name, rating, message, status, submitted_at) VALUES (?, ?, ?, ?, ?)',
      [cleanName, numRating, cleanMsg, 'PENDING', now]
    );

    res.status(201).json({
      success: true,
      message: 'Thank you for your valuable feedback! It has been submitted for moderation.',
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to submit feedback. Please try again.', details: err.message });
  }
});

// 7. Submit Business & Customer Support Enquiry
app.post('/api/public/enquiry', (req: Request, res: Response) => {
  try {
    const { customer_name, mobile_number, email, category, organization, subject, message } = req.body;

    if (!customer_name || typeof customer_name !== 'string' || !customer_name.trim()) {
      res.status(400).json({ error: 'Please enter your Full Name.' });
      return;
    }
    if (!mobile_number || typeof mobile_number !== 'string' || !mobile_number.trim()) {
      res.status(400).json({ error: 'Please enter a valid Mobile Number.' });
      return;
    }
    const digitsOnly = mobile_number.replace(/\D/g, '');
    if (digitsOnly.length < 10) {
      res.status(400).json({ error: 'Please enter a valid 10-digit mobile phone number.' });
      return;
    }
    if (!category || typeof category !== 'string' || !category.trim()) {
      res.status(400).json({ error: 'Please select an Enquiry Category.' });
      return;
    }
    if (!subject || typeof subject !== 'string' || !subject.trim()) {
      res.status(400).json({ error: 'Please enter a Subject for your request.' });
      return;
    }
    if (!message || typeof message !== 'string' || !message.trim()) {
      res.status(400).json({ error: 'Please enter your Message.' });
      return;
    }

    const cleanName = customer_name.trim().slice(0, 150);
    const cleanMobile = mobile_number.trim().slice(0, 50);
    const cleanEmail = email && typeof email === 'string' && email.trim() ? email.trim().slice(0, 150) : null;
    const cleanCategory = category.trim().slice(0, 100);
    const cleanOrg = organization && typeof organization === 'string' && organization.trim() ? organization.trim().slice(0, 200) : null;
    const cleanSubject = subject.trim().slice(0, 255);
    const cleanMsg = message.trim().slice(0, 4000);
    const now = new Date().toISOString();

    // Generate unique reference number (e.g., RP-2026-73821)
    const year = new Date().getFullYear();
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const referenceNo = `RP-${year}-${randomSuffix}`;

    execute(
      `INSERT INTO enquiries (reference_no, customer_name, mobile_number, email, category, organization, subject, message, status, submitted_at, updated_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [referenceNo, cleanName, cleanMobile, cleanEmail, cleanCategory, cleanOrg, cleanSubject, cleanMsg, 'New', now, now]
    );

    res.status(201).json({
      success: true,
      reference_no: referenceNo,
      message: 'Thank you for contacting Raj Petroleum. Your request has been submitted successfully.',
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to submit enquiry. Please try again.', details: err.message });
  }
});


// ---------------------------------------------------------------------------
// ADMIN AUTHENTICATION
// ---------------------------------------------------------------------------

app.post('/api/admin/login', async (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  if (!checkLoginRateLimit(ip)) {
    res.status(429).json({ error: 'Too many login attempts. Please wait 5 minutes and try again.' });
    return;
  }

  const { username, password } = req.body;

  if (!username || !password) {
    res.status(400).json({ error: 'Invalid username or password.' });
    return;
  }

  try {
    const admin = queryOne<{ id: number; username: string; password_hash: string }>(
      'SELECT id, username, password_hash FROM administrators WHERE username = ?',
      [username.trim()]
    );

    if (!admin) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    const isMatch = await bcrypt.compare(password, admin.password_hash);
    if (!isMatch) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    // Generate JWT token valid for 24 hours
    const token = jwt.sign(
      { id: admin.id, username: admin.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    const now = new Date().toISOString();
    execute('INSERT INTO audit_logs (action, details, ip_address, created_at) VALUES (?, ?, ?, ?)', [
      'LOGIN_SUCCESS',
      `Admin ${admin.username} logged in successfully`,
      ip,
      now,
    ]);

    res.json({
      success: true,
      token,
      user: {
        id: admin.id,
        username: admin.username,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Server authentication error', details: err.message });
  }
});

app.post('/api/admin/logout', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = req.adminUser;
  if (user) {
    execute('INSERT INTO audit_logs (action, details, ip_address, created_at) VALUES (?, ?, ?, ?)', [
      'LOGOUT',
      `Admin ${user.username} logged out`,
      req.ip || 'unknown',
      new Date().toISOString(),
    ]);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

app.get('/api/admin/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  res.json({ user: req.adminUser });
});

// ---------------------------------------------------------------------------
// ADMIN PROTECTED CRUD ROUTES
// ---------------------------------------------------------------------------

// Admin Dashboard Overview Statistics
app.get('/api/admin/stats', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const fuelCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM fuel_categories');
    const serviceCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM customer_services');
    const galleryCount = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM gallery_images');
    const pendingFeedback = queryOne<{ count: number }>("SELECT COUNT(*) AS count FROM feedback_submissions WHERE status = 'PENDING'");
    const approvedReviews = queryOne<{ count: number }>("SELECT COUNT(*) AS count FROM feedback_submissions WHERE status = 'APPROVED'");
    const totalEnquiries = queryOne<{ count: number }>('SELECT COUNT(*) AS count FROM enquiries');
    const pendingEnquiries = queryOne<{ count: number }>(
      "SELECT COUNT(*) AS count FROM enquiries WHERE status = 'New' OR status = 'PENDING' OR status = 'In Progress' OR status = 'IN_PROGRESS'"
    );
    const resolvedEnquiries = queryOne<{ count: number }>(
      "SELECT COUNT(*) AS count FROM enquiries WHERE status = 'Resolved' OR status = 'RESOLVED' OR status = 'Responded'"
    );

    res.json({
      fuelCategories: fuelCount?.count || 0,
      customerServices: serviceCount?.count || 0,
      galleryImages: galleryCount?.count || 0,
      pendingFeedback: pendingFeedback?.count || 0,
      approvedReviews: approvedReviews?.count || 0,
      totalEnquiries: totalEnquiries?.count || 0,
      pendingEnquiries: pendingEnquiries?.count || 0,
      resolvedEnquiries: resolvedEnquiries?.count || 0,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch statistics', details: err.message });
  }
});

// Business Settings CRUD
app.get('/api/admin/settings', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const settings = queryOne('SELECT * FROM business_settings LIMIT 1');
    res.json(settings || {});
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch settings', details: err.message });
  }
});

app.put('/api/admin/settings', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { business_name, owner_name, address, plus_code, phone, whatsapp, email, opening_hours, description } = req.body;
    const now = new Date().toISOString();

    const existing = queryOne('SELECT id FROM business_settings LIMIT 1');
    if (existing) {
      execute(
        `UPDATE business_settings 
         SET business_name = ?, owner_name = ?, address = ?, plus_code = ?, phone = ?, whatsapp = ?, email = ?, opening_hours = ?, description = ?, updated_at = ?
         WHERE id = ?`,
        [business_name, owner_name, address, plus_code, phone, whatsapp || '8766660414', email, opening_hours, description, now, existing.id]
      );
    } else {
      execute(
        `INSERT INTO business_settings (business_name, owner_name, address, plus_code, phone, whatsapp, email, opening_hours, description, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [business_name, owner_name, address, plus_code, phone, whatsapp || '8766660414', email, opening_hours, description, now]
      );
    }

    res.json({ success: true, message: 'Business settings updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update settings', details: err.message });
  }
});


// Homepage Appearance Management
app.get('/api/admin/appearance', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const appearance = queryOne('SELECT * FROM homepage_appearance LIMIT 1');
    res.json(appearance || {
      background_image: '/assets/raj-petroleum-hero.jpg',
      position: 'center',
      display_mode: 'cover',
      overlay_intensity: 0.45,
      hero_height: 640,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch appearance settings', details: err.message });
  }
});

app.put('/api/admin/appearance', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { background_image, position, display_mode, overlay_intensity, hero_height } = req.body;
    const now = new Date().toISOString();
    const pos = ['center', 'top', 'bottom'].includes(position) ? position : 'center';
    const mode = ['cover', 'contain'].includes(display_mode) ? display_mode : 'cover';
    const intensity = Math.min(Math.max(parseFloat(overlay_intensity) || 0.45, 0.1), 0.9);
    const height = Math.min(Math.max(parseInt(hero_height, 10) || 640, 420), 850);
    const bgImage =
      background_image && typeof background_image === 'string' && background_image.trim()
        ? background_image.trim()
        : '/assets/raj-petroleum-hero.jpg';

    const existing = queryOne('SELECT id FROM homepage_appearance LIMIT 1');
    if (existing) {
      execute(
        `UPDATE homepage_appearance 
         SET background_image = ?, position = ?, display_mode = ?, overlay_intensity = ?, hero_height = ?, updated_at = ?
         WHERE id = ?`,
        [bgImage, pos, mode, intensity, height, now, existing.id]
      );
    } else {
      execute(
        `INSERT INTO homepage_appearance (background_image, position, display_mode, overlay_intensity, hero_height, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [bgImage, pos, mode, intensity, height, now]
      );
    }

    res.json({ success: true, message: 'Homepage appearance settings saved successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update appearance settings', details: err.message });
  }
});

app.post('/api/admin/appearance/upload', requireAuth, upload.single('image'), (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No image file uploaded.' });
      return;
    }
    const publicUrl = `/uploads/${req.file.filename}`;
    res.json({ success: true, url: publicUrl, filename: req.file.filename });
  } catch (err: any) {
    res.status(500).json({ error: 'Background upload failed', details: err.message });
  }
});

app.delete('/api/admin/appearance/image', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const existing = queryOne<{ id: number; background_image: string }>('SELECT id, background_image FROM homepage_appearance LIMIT 1');
    if (existing && existing.background_image && existing.background_image.startsWith('/uploads/')) {
      const filename = path.basename(existing.background_image);
      const filePath = path.join(UPLOADS_DIR, filename);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.warn('Could not remove file on disk:', e);
        }
      }
    }
    const now = new Date().toISOString();
    if (existing) {
      execute(
        'UPDATE homepage_appearance SET background_image = ?, updated_at = ? WHERE id = ?',
        ['/assets/raj-petroleum-hero.jpg', now, existing.id]
      );
    }
    res.json({ success: true, message: 'Homepage background image reset to default.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reset background image', details: err.message });
  }
});

// Fuel Categories CRUD
app.get('/api/admin/fuel-prices', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const prices = queryAll('SELECT * FROM fuel_categories ORDER BY display_order ASC, id ASC');
    res.json(prices);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch fuel categories', details: err.message });
  }
});

app.post('/api/admin/fuel-prices', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { name, price_per_litre, effective_date, is_active, display_order } = req.body;
    if (!name || !name.trim()) {
      res.status(400).json({ error: 'Fuel category name is required.' });
      return;
    }
    const priceNum = parseFloat(price_per_litre) || 0;
    const effDate = effective_date || new Date().toISOString().split('T')[0];
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;
    const now = new Date().toISOString();

    const result = execute(
      'INSERT INTO fuel_categories (name, price_per_litre, effective_date, is_active, display_order, updated_at) VALUES (?, ?, ?, ?, ?, ?)',
      [name.trim(), priceNum, effDate, activeVal, orderNum, now]
    );

    res.status(201).json({ success: true, message: 'Fuel category created successfully.', id: result.lastInsertRowid });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create fuel category. Name must be unique.', details: err.message });
  }
});

app.put('/api/admin/fuel-prices/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { name, price_per_litre, effective_date, is_active, display_order } = req.body;

    const existing = queryOne('SELECT id FROM fuel_categories WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Fuel category not found.' });
      return;
    }

    const priceNum = parseFloat(price_per_litre) || 0;
    const effDate = effective_date || new Date().toISOString().split('T')[0];
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;
    const now = new Date().toISOString();

    execute(
      'UPDATE fuel_categories SET name = ?, price_per_litre = ?, effective_date = ?, is_active = ?, display_order = ?, updated_at = ? WHERE id = ?',
      [name.trim(), priceNum, effDate, activeVal, orderNum, now, id]
    );

    res.json({ success: true, message: 'Fuel category updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update fuel category', details: err.message });
  }
});

app.delete('/api/admin/fuel-prices/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = queryOne('SELECT id, name FROM fuel_categories WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Fuel category not found.' });
      return;
    }

    execute('DELETE FROM fuel_categories WHERE id = ?', [id]);
    res.json({ success: true, message: `Fuel category "${existing.name}" removed successfully.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete fuel category', details: err.message });
  }
});

// Customer Services CRUD
app.get('/api/admin/services', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const services = queryAll('SELECT * FROM customer_services ORDER BY display_order ASC, id ASC');
    res.json(services);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch services', details: err.message });
  }
});

app.post('/api/admin/services', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { title, description, icon_name, icon_image_url, is_active, display_order } = req.body;
    if (!title || !title.trim()) {
      res.status(400).json({ error: 'Service title is required.' });
      return;
    }
    const now = new Date().toISOString();
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    const result = execute(
      'INSERT INTO customer_services (title, description, icon_name, icon_image_url, is_active, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [title.trim(), (description || '').trim(), icon_name || 'Fuel', icon_image_url || null, activeVal, orderNum, now, now]
    );

    res.status(201).json({ success: true, message: 'Service added successfully.', id: result.lastInsertRowid });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to add service', details: err.message });
  }
});

app.put('/api/admin/services/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { title, description, icon_name, icon_image_url, is_active, display_order } = req.body;

    const existing = queryOne('SELECT id FROM customer_services WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Service not found.' });
      return;
    }

    const now = new Date().toISOString();
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    execute(
      'UPDATE customer_services SET title = ?, description = ?, icon_name = ?, icon_image_url = ?, is_active = ?, display_order = ?, updated_at = ? WHERE id = ?',
      [title.trim(), (description || '').trim(), icon_name || 'Fuel', icon_image_url !== undefined ? icon_image_url : null, activeVal, orderNum, now, id]
    );

    res.json({ success: true, message: 'Service updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update service', details: err.message });
  }
});

app.delete('/api/admin/services/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    execute('DELETE FROM customer_services WHERE id = ?', [id]);
    res.json({ success: true, message: 'Service deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete service', details: err.message });
  }
});

// Gallery Management CRUD & File Uploads
app.get('/api/admin/gallery', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const images = queryAll('SELECT * FROM gallery_images ORDER BY display_order ASC, id DESC');
    res.json(images);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch gallery images', details: err.message });
  }
});

// File upload endpoint
app.post('/api/admin/upload', requireAuth, upload.single('image'), (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No image file uploaded.' });
      return;
    }
    const publicUrl = `/uploads/${req.file.filename}`;
    res.json({ success: true, url: publicUrl, filename: req.file.filename });
  } catch (err: any) {
    res.status(500).json({ error: 'Image upload failed', details: err.message });
  }
});

app.post('/api/admin/gallery', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { title, description, image_url, is_active, display_order } = req.body;
    if (!image_url || !image_url.trim()) {
      res.status(400).json({ error: 'Image URL or uploaded file is required.' });
      return;
    }
    const now = new Date().toISOString();
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    const result = execute(
      'INSERT INTO gallery_images (title, description, image_url, is_active, display_order, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [title ? title.trim() : 'Raj Petroleum Gallery Image', (description || '').trim(), image_url.trim(), activeVal, orderNum, now]
    );

    res.status(201).json({ success: true, message: 'Gallery image added successfully.', id: result.lastInsertRowid });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to add gallery image', details: err.message });
  }
});

app.put('/api/admin/gallery/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { title, description, image_url, is_active, display_order } = req.body;

    const existing = queryOne('SELECT id FROM gallery_images WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Gallery image not found.' });
      return;
    }

    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    execute(
      'UPDATE gallery_images SET title = ?, description = ?, image_url = ?, is_active = ?, display_order = ? WHERE id = ?',
      [title ? title.trim() : 'Raj Petroleum Gallery Image', (description || '').trim(), image_url.trim(), activeVal, orderNum, id]
    );

    res.json({ success: true, message: 'Gallery image updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update gallery image', details: err.message });
  }
});

app.delete('/api/admin/gallery/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const existing = queryOne<{ id: number; image_url: string }>('SELECT id, image_url FROM gallery_images WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Gallery image not found.' });
      return;
    }

    // Safely remove file if it was uploaded to /uploads/
    if (existing.image_url && existing.image_url.startsWith('/uploads/')) {
      const filename = path.basename(existing.image_url);
      const filePath = path.join(UPLOADS_DIR, filename);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.warn('Could not remove file on disk:', e);
        }
      }
    }

    execute('DELETE FROM gallery_images WHERE id = ?', [id]);
    res.json({ success: true, message: 'Gallery image removed successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete gallery image', details: err.message });
  }
});

// Feedback & Moderation CRUD
app.get('/api/admin/feedback', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const submissions = queryAll('SELECT * FROM feedback_submissions ORDER BY id DESC');
    res.json(submissions);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch feedback submissions', details: err.message });
  }
});

app.put('/api/admin/feedback/:id/status', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status } = req.body;
    if (!['PENDING', 'APPROVED', 'REJECTED'].includes(status)) {
      res.status(400).json({ error: 'Status must be PENDING, APPROVED, or REJECTED.' });
      return;
    }

    const now = new Date().toISOString();
    execute('UPDATE feedback_submissions SET status = ?, reviewed_at = ? WHERE id = ?', [status, now, id]);

    res.json({ success: true, message: `Review status updated to ${status}.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update feedback status', details: err.message });
  }
});

app.delete('/api/admin/feedback/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    execute('DELETE FROM feedback_submissions WHERE id = ?', [id]);
    res.json({ success: true, message: 'Feedback entry deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete feedback entry', details: err.message });
  }
});

// Enquiries CRUD
app.get('/api/admin/enquiries', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const enquiries = queryAll('SELECT * FROM enquiries ORDER BY id DESC');
    res.json(enquiries);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch enquiries', details: err.message });
  }
});

app.put('/api/admin/enquiries/:id/status', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status, admin_notes } = req.body;
    const allowed = ['New', 'In Progress', 'Responded', 'Resolved', 'PENDING', 'IN_PROGRESS', 'RESOLVED'];
    if (status && !allowed.includes(status)) {
      res.status(400).json({ error: 'Status must be New, In Progress, Responded, or Resolved.' });
      return;
    }

    const now = new Date().toISOString();
    if (status && admin_notes !== undefined) {
      execute('UPDATE enquiries SET status = ?, admin_notes = ?, updated_at = ? WHERE id = ?', [status, admin_notes, now, id]);
    } else if (status) {
      execute('UPDATE enquiries SET status = ?, updated_at = ? WHERE id = ?', [status, now, id]);
    } else if (admin_notes !== undefined) {
      execute('UPDATE enquiries SET admin_notes = ?, updated_at = ? WHERE id = ?', [admin_notes, now, id]);
    }

    res.json({ success: true, message: 'Enquiry updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update enquiry', details: err.message });
  }
});


app.delete('/api/admin/enquiries/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    execute('DELETE FROM enquiries WHERE id = ?', [id]);
    res.json({ success: true, message: 'Enquiry record removed successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete enquiry', details: err.message });
  }
});

// Announcements CRUD
app.get('/api/admin/announcements', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const list = queryAll('SELECT * FROM announcements ORDER BY display_order ASC, id DESC');
    res.json(list);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch announcements', details: err.message });
  }
});

app.post('/api/admin/announcements', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { message, link_url, is_active, display_order, start_date, end_date } = req.body;
    if (!message || !message.trim()) {
      res.status(400).json({ error: 'Announcement message is required.' });
      return;
    }
    const now = new Date().toISOString();
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    const result = execute(
      'INSERT INTO announcements (message, link_url, is_active, display_order, start_date, end_date, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [
        message.trim(),
        (link_url || '').trim() || null,
        activeVal,
        orderNum,
        start_date || null,
        end_date || null,
        now,
        now,
      ]
    );

    res.status(201).json({ success: true, message: 'Announcement created successfully.', id: result.lastInsertRowid });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create announcement', details: err.message });
  }
});

app.put('/api/admin/announcements/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { message, link_url, is_active, display_order, start_date, end_date } = req.body;

    const existing = queryOne('SELECT id FROM announcements WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Announcement not found.' });
      return;
    }

    const now = new Date().toISOString();
    const activeVal = is_active === false || is_active === 0 ? 0 : 1;
    const orderNum = parseInt(display_order, 10) || 0;

    execute(
      'UPDATE announcements SET message = ?, link_url = ?, is_active = ?, display_order = ?, start_date = ?, end_date = ?, updated_at = ? WHERE id = ?',
      [
        message.trim(),
        (link_url || '').trim() || null,
        activeVal,
        orderNum,
        start_date || null,
        end_date || null,
        now,
        id,
      ]
    );

    res.json({ success: true, message: 'Announcement updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update announcement', details: err.message });
  }
});

app.delete('/api/admin/announcements/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    execute('DELETE FROM announcements WHERE id = ?', [id]);
    res.json({ success: true, message: 'Announcement removed successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete announcement', details: err.message });
  }
});

// Branding & Logo Management
app.get('/api/admin/branding', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const branding = queryOne(
      'SELECT id, logo_url, logo_height, brand_name, tagline, updated_at FROM branding_settings LIMIT 1'
    ) || {
      logo_url: '/assets/hp-logo.png',
      logo_height: 56,
      brand_name: 'RAJ PETROLEUM',
      tagline: 'Hindustan Petroleum Retail Outlet',
    };
    res.json(branding);
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch branding settings', details: err.message });
  }
});

app.put('/api/admin/branding', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const { logo_url, logo_height, brand_name, tagline } = req.body;
    const existing = queryOne<{ id: number }>('SELECT id FROM branding_settings LIMIT 1');
    const now = new Date().toISOString();

    const logoUrl = (logo_url || '').trim() || '/assets/hp-logo.png';
    const logoHeight = Math.min(120, Math.max(30, parseInt(logo_height, 10) || 56));
    const brandName = (brand_name || '').trim() || 'RAJ PETROLEUM';
    const brandTagline = (tagline || '').trim() || 'Hindustan Petroleum Retail Outlet';

    if (existing) {
      execute(
        'UPDATE branding_settings SET logo_url = ?, logo_height = ?, brand_name = ?, tagline = ?, updated_at = ? WHERE id = ?',
        [logoUrl, logoHeight, brandName, brandTagline, now, existing.id]
      );
    } else {
      execute(
        'INSERT INTO branding_settings (logo_url, logo_height, brand_name, tagline, updated_at) VALUES (?, ?, ?, ?, ?)',
        [logoUrl, logoHeight, brandName, brandTagline, now]
      );
    }

    res.json({ success: true, message: 'Branding settings updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update branding settings', details: err.message });
  }
});

app.post('/api/admin/branding/logo', requireAuth, upload.single('image'), (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No logo file uploaded.' });
      return;
    }
    const publicUrl = `/uploads/${req.file.filename}`;
    res.json({ success: true, url: publicUrl, filename: req.file.filename });
  } catch (err: any) {
    res.status(500).json({ error: 'Logo upload failed', details: err.message });
  }
});

app.delete('/api/admin/branding/logo', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const existing = queryOne<{ id: number; logo_url: string }>('SELECT id, logo_url FROM branding_settings LIMIT 1');
    if (existing && existing.logo_url && existing.logo_url.startsWith('/uploads/')) {
      const filename = path.basename(existing.logo_url);
      const filePath = path.join(UPLOADS_DIR, filename);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.warn('Could not remove file on disk:', e);
        }
      }
    }
    const now = new Date().toISOString();
    if (existing) {
      execute('UPDATE branding_settings SET logo_url = ?, updated_at = ? WHERE id = ?', [
        '/assets/hp-logo.png',
        now,
        existing.id,
      ]);
    }
    res.json({ success: true, message: 'Logo reset to official HP default logo.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reset logo', details: err.message });
  }
});

// ---------------------------------------------------------------------------
// HP PAY APP MANAGEMENT ENDPOINTS
// ---------------------------------------------------------------------------
app.get('/api/admin/hp-pay', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    let row = queryOne<any>('SELECT * FROM hp_pay_section LIMIT 1');
    if (!row) {
      const now = new Date().toISOString();
      const defaultFeatures = [
        {
          id: 'feat_1',
          title: 'Contactless Fuel Payments',
          description: 'Pay quickly and securely for Petrol, Diesel, and HP Power Petrol via UPI, Credit/Debit cards, or HP Pay Wallet without handling cash.',
          icon: 'CreditCard',
        },
        {
          id: 'feat_2',
          title: 'Scan QR & Instant Paycode',
          description: 'Scan dynamic HPCL QR codes at our forecourt dispensers or generate a one-time Paycode for touchless refueling transactions.',
          icon: 'QrCode',
        },
        {
          id: 'feat_3',
          title: 'Integrated HP Pay Wallet & FASTag',
          description: 'Maintain a dedicated fuel wallet, recharge toll FASTag, and monitor all your commercial or private vehicle fueling expenses in real time.',
          icon: 'Wallet',
        },
        {
          id: 'feat_4',
          title: 'Earn & Redeem Reward Points',
          description: 'Accumulate loyalty points on every fuel purchase and redeem them directly for free fuel at authorized Hindustan Petroleum outlets.',
          icon: 'Gift',
        },
        {
          id: 'feat_5',
          title: 'HP Gas LPG Cylinder Booking',
          description: 'Book and pay for domestic or commercial HP Gas LPG refills conveniently from your smartphone with digital receipts.',
          icon: 'Flame',
        },
        {
          id: 'feat_6',
          title: 'Forecourt & Outlet Locator',
          description: 'Locate authorized HPCL retail outlets across national and state highways with live services, air stations, and facility details.',
          icon: 'MapPin',
        },
      ];
      execute(
        `INSERT INTO hp_pay_section (title, heading, description, app_icon_url, play_store_url, learn_more_url, is_visible, is_deleted, display_order, features_json, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'HP Pay App',
          'Discover HP Pay',
          'HP Pay is a digital payment and convenience application from Hindustan Petroleum Corporation Limited (HPCL). Explore the app\'s supported fuel payment options, digital payment features, rewards, and other available services.',
          '/assets/hp-pay-logo.png',
          'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel',
          'https://www.hindustanpetroleum.com/pages/mobile-app',
          1,
          0,
          6,
          JSON.stringify(defaultFeatures),
          now,
          now,
        ]
      );
      row = queryOne<any>('SELECT * FROM hp_pay_section LIMIT 1');
    }

    let features = [];
    try {
      features = JSON.parse(row.features_json || '[]');
    } catch {
      features = [];
    }

    res.json({
      ...row,
      features,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch HP Pay configuration', details: err.message });
  }
});

app.put('/api/admin/hp-pay', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      title,
      heading,
      description,
      app_icon_url,
      play_store_url,
      learn_more_url,
      is_visible,
      display_order,
      features,
    } = req.body;

    const row = queryOne<{ id: number }>('SELECT id FROM hp_pay_section LIMIT 1');
    const now = new Date().toISOString();
    const finalTitle = (title || '').trim() || 'HP Pay App';
    const finalHeading = (heading || '').trim() || 'Discover HP Pay';
    const finalDescription = (description || '').trim();
    const finalIcon = (app_icon_url || '').trim() || '/assets/hp-pay-logo.png';
    const finalPlayStore = (play_store_url || '').trim() || 'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel';
    const finalLearnMore = (learn_more_url || '').trim() || 'https://www.hindustanpetroleum.com/pages/mobile-app';
    const finalVisible = is_visible === 0 || is_visible === false ? 0 : 1;
    const finalOrder = parseInt(display_order, 10) || 6;
    const finalFeaturesJson = JSON.stringify(Array.isArray(features) ? features : []);

    if (row) {
      execute(
        `UPDATE hp_pay_section
         SET title = ?, heading = ?, description = ?, app_icon_url = ?, play_store_url = ?, learn_more_url = ?, is_visible = ?, is_deleted = 0, display_order = ?, features_json = ?, updated_at = ?
         WHERE id = ?`,
        [
          finalTitle,
          finalHeading,
          finalDescription,
          finalIcon,
          finalPlayStore,
          finalLearnMore,
          finalVisible,
          finalOrder,
          finalFeaturesJson,
          now,
          row.id,
        ]
      );
    } else {
      execute(
        `INSERT INTO hp_pay_section (title, heading, description, app_icon_url, play_store_url, learn_more_url, is_visible, is_deleted, display_order, features_json, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?)`,
        [
          finalTitle,
          finalHeading,
          finalDescription,
          finalIcon,
          finalPlayStore,
          finalLearnMore,
          finalVisible,
          finalOrder,
          finalFeaturesJson,
          now,
          now,
        ]
      );
    }

    res.json({ success: true, message: 'HP Pay section updated and published successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update HP Pay section', details: err.message });
  }
});

app.delete('/api/admin/hp-pay', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const now = new Date().toISOString();
    execute('UPDATE hp_pay_section SET is_deleted = 1, is_visible = 0, updated_at = ?', [now]);
    res.json({ success: true, message: 'HP Pay section removed from website successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete HP Pay section', details: err.message });
  }
});

app.post('/api/admin/hp-pay/reset', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  try {
    const now = new Date().toISOString();
    const defaultFeatures = [
      {
        id: 'feat_1',
        title: 'Contactless Fuel Payments',
        description: 'Pay quickly and securely for Petrol, Diesel, and HP Power Petrol via UPI, Credit/Debit cards, or HP Pay Wallet without handling cash.',
        icon: 'CreditCard',
      },
      {
        id: 'feat_2',
        title: 'Scan QR & Instant Paycode',
        description: 'Scan dynamic HPCL QR codes at our forecourt dispensers or generate a one-time Paycode for touchless refueling transactions.',
        icon: 'QrCode',
      },
      {
        id: 'feat_3',
        title: 'Integrated HP Pay Wallet & FASTag',
        description: 'Maintain a dedicated fuel wallet, recharge toll FASTag, and monitor all your commercial or private vehicle fueling expenses in real time.',
        icon: 'Wallet',
      },
      {
        id: 'feat_4',
        title: 'Earn & Redeem Reward Points',
        description: 'Accumulate loyalty points on every fuel purchase and redeem them directly for free fuel at authorized Hindustan Petroleum outlets.',
        icon: 'Gift',
      },
      {
        id: 'feat_5',
        title: 'HP Gas LPG Cylinder Booking',
        description: 'Book and pay for domestic or commercial HP Gas LPG refills conveniently from your smartphone with digital receipts.',
        icon: 'Flame',
      },
      {
        id: 'feat_6',
        title: 'Forecourt & Outlet Locator',
        description: 'Locate authorized HPCL retail outlets across national and state highways with live services, air stations, and facility details.',
        icon: 'MapPin',
      },
    ];

    const existing = queryOne<{ id: number }>('SELECT id FROM hp_pay_section LIMIT 1');
    if (existing) {
      execute(
        `UPDATE hp_pay_section
         SET title = 'HP Pay App',
             heading = 'Discover HP Pay',
             description = 'HP Pay is a digital payment and convenience application from Hindustan Petroleum Corporation Limited (HPCL). Explore the app\'s supported fuel payment options, digital payment features, rewards, and other available services.',
             app_icon_url = '/assets/hp-pay-logo.png',
             play_store_url = 'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel',
             learn_more_url = 'https://www.hindustanpetroleum.com/pages/mobile-app',
             is_visible = 1,
             is_deleted = 0,
             display_order = 6,
             features_json = ?,
             updated_at = ?
         WHERE id = ?`,
        [JSON.stringify(defaultFeatures), now, existing.id]
      );
    } else {
      execute(
        `INSERT INTO hp_pay_section (title, heading, description, app_icon_url, play_store_url, learn_more_url, is_visible, is_deleted, display_order, features_json, created_at, updated_at)
         VALUES ('HP Pay App', 'Discover HP Pay', 'HP Pay is a digital payment and convenience application from Hindustan Petroleum Corporation Limited (HPCL). Explore the app\'s supported fuel payment options, digital payment features, rewards, and other available services.', '/assets/hp-pay-logo.png', 'https://play.google.com/store/apps/details?id=com.drivetrackplusrefuel', 'https://www.hindustanpetroleum.com/pages/mobile-app', 1, 0, 6, ?, ?, ?)`,
        [JSON.stringify(defaultFeatures), now, now]
      );
    }

    res.json({ success: true, message: 'HP Pay section recreated and restored to defaults.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to reset HP Pay section', details: err.message });
  }
});

app.post('/api/admin/hp-pay/icon', requireAuth, upload.single('icon'), (req: AuthenticatedRequest, res: Response) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No icon file uploaded.' });
      return;
    }
    const publicUrl = `/uploads/${req.file.filename}`;
    res.json({ success: true, url: publicUrl, filename: req.file.filename });
  } catch (err: any) {
    res.status(500).json({ error: 'App icon upload failed', details: err.message });
  }
});

// Admin Account Settings - Change Password
app.put('/api/admin/change-password', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const adminUser = req.adminUser;
    if (!adminUser) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    if (!currentPassword || !newPassword || newPassword.length < 6) {
      res.status(400).json({ error: 'New password must be at least 6 characters long.' });
      return;
    }

    const admin = queryOne<{ id: number; password_hash: string }>(
      'SELECT id, password_hash FROM administrators WHERE id = ?',
      [adminUser.id]
    );

    if (!admin) {
      res.status(404).json({ error: 'Administrator not found.' });
      return;
    }

    const isMatch = await bcrypt.compare(currentPassword, admin.password_hash);
    if (!isMatch) {
      res.status(400).json({ error: 'Current password does not match.' });
      return;
    }

    const newHash = await bcrypt.hash(newPassword, 10);
    const now = new Date().toISOString();
    execute('UPDATE administrators SET password_hash = ?, updated_at = ? WHERE id = ?', [newHash, now, admin.id]);

    execute('INSERT INTO audit_logs (action, details, ip_address, created_at) VALUES (?, ?, ?, ?)', [
      'PASSWORD_CHANGED',
      `Admin ${adminUser.username} updated their password`,
      req.ip || 'unknown',
      now,
    ]);

    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to change password', details: err.message });
  }
});

// Centralized error handler
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('[Server Error]', err);
  res.status(500).json({ error: err.message || 'Internal Server Error' });
});

// Initialize Database & Start Server
async function startServer() {
  await initDatabase();

  if (!isProd) {
    // In dev mode, mount Vite middleware as required by full-stack guidelines
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    // Development SPA HTML fallback so direct navigation and page refresh on /admin/login & /admin/dashboard work!
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      if (url.startsWith('/api') || url.startsWith('/uploads') || url.startsWith('/assets')) {
        return next();
      }
      try {
        const indexPath = path.resolve(__dirname, 'index.html');
        let template = fs.readFileSync(indexPath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // In production, serve dist assets
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res, next) => {
      if (req.originalUrl.startsWith('/api') || req.originalUrl.startsWith('/uploads')) {
        return next();
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Raj Petroleum Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Fatal Error starting server]', err);
  process.exit(1);
});
